import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function ProductCard({ product, onAddToCart, isWishlisted, onWishlistToggle }) {
  const { isAuthenticated } = useAuth();

  const imageUrl = product.image
    ? (product.image.startsWith('http') ? product.image : `http://127.0.0.1:8000${product.image}`)
    : 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80';

  const price = parseFloat(product.price) || 0;

  const handleWishlistClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      alert('Please login to add to wishlist!');
      return;
    }
    try {
      const res = await api.post(`/products/wishlist/toggle/${product.id}/`);
      if (onWishlistToggle) {
        onWishlistToggle(product.id, res.data.in_wishlist);
      }
    } catch (err) {
      console.error('Wishlist error:', err);
      alert('Failed to update wishlist.');
    }
  };

  return (
    <div style={styles.card}>
      <Link to={`/products/${product.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
        <div style={styles.imageContainer}>
          <img src={imageUrl} alt={product.name} style={styles.image} />
          {product.stock <= 0 && <span style={styles.soldOutBadge}>Sold Out</span>}
          
          {/* Top-Right Floating Wishlist Icon */}
          <button
            type="button"
            onClick={handleWishlistClick}
            title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
            style={styles.floatingWishlistBtn}
          >
            {isWishlisted ? '❤️' : '🤍'}
          </button>
        </div>

        <div style={styles.details}>
          <span style={styles.category}>{product.category?.name || 'Curated'}</span>
          <h4 style={styles.title}>{product.name}</h4>
          <div style={styles.priceRow}>
            <span style={styles.price}>${price.toFixed(2)}</span>
          </div>
        </div>
      </Link>

      {/* Buttons Container */}
      <div style={styles.btnRow}>
        <button
          style={product.stock > 0 ? styles.addBtn : styles.disabledBtn}
          disabled={product.stock <= 0}
          onClick={() => onAddToCart && onAddToCart(product)}
        >
          {product.stock > 0 ? '+ Add to Bag' : 'Out of Stock'}
        </button>

        <button
          type="button"
          onClick={handleWishlistClick}
          title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
          style={styles.wishlistBtn}
        >
          {isWishlisted ? '❤️' : '🤍'}
        </button>
      </div>
    </div>
  );
}

const styles = {
  card: {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    border: '1px solid #f1f5f9',
    transition: 'all 0.3s ease',
  },
  imageContainer: {
    position: 'relative',
    width: '100%',
    height: '240px',
    backgroundColor: '#f8fafc',
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    transition: 'transform 0.3s ease',
  },
  soldOutBadge: {
    position: 'absolute',
    top: '12px',
    left: '12px',
    backgroundColor: '#0f172a',
    color: '#ffffff',
    fontSize: '0.7rem',
    fontWeight: '700',
    padding: '4px 10px',
    borderRadius: '100px',
    textTransform: 'uppercase',
    zIndex: 1,
  },
  floatingWishlistBtn: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'rgba(255, 255, 255, 0.9)',
    border: '1px solid #e2e8f0',
    borderRadius: '50%',
    width: '34px',
    height: '34px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    fontSize: '1rem',
    zIndex: 2,
    boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
  },
  details: {
    padding: '16px 14px 10px',
  },
  category: {
    fontSize: '0.75rem',
    textTransform: 'uppercase',
    letterSpacing: '0.8px',
    color: '#94a3b8',
    fontWeight: '700',
  },
  title: {
    fontSize: '0.95rem',
    fontWeight: '600',
    color: '#0f172a',
    margin: '6px 0 8px 0',
    lineHeight: '1.4',
    height: '2.8em',
    overflow: 'hidden',
  },
  priceRow: {
    display: 'flex',
    alignItems: 'center',
  },
  price: {
    fontSize: '1.1rem',
    fontWeight: '800',
    color: '#0f172a',
  },
  btnRow: {
    display: 'flex',
    gap: '8px',
    margin: '0 14px 14px',
  },
  addBtn: {
    flex: 1,
    backgroundColor: '#0f172a',
    color: '#ffffff',
    border: 'none',
    padding: '10px 0',
    borderRadius: '8px',
    fontSize: '0.85rem',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background 0.2s',
  },
  disabledBtn: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    color: '#94a3b8',
    border: 'none',
    padding: '10px 0',
    borderRadius: '8px',
    fontSize: '0.85rem',
    fontWeight: '600',
    cursor: 'not-allowed',
  },
  wishlistBtn: {
    padding: '0 12px',
    backgroundColor: '#ffffff',
    border: '1px solid #cbd5e1',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '1.1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
