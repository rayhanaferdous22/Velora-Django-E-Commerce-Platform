import { useEffect, useState } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Home({ addToCart }) {
  const [products, setProducts] = useState([]);
  const [wishlistIds, setWishlistIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    // ১. প্রোডাক্ট লোড করা
    api
      .get('/products/')
      .then((res) => {
        const data = Array.isArray(res.data) ? res.data : res.data.results || [];
        setProducts(data);
      })
      .catch((err) => {
        console.error('Fetch error:', err);
        setError('Failed to load products from Django.');
      })
      .finally(() => {
        setLoading(false);
      });

    // ২. লগইন থাকলে ইউজারের বর্তমান Wishlist লোড করা
    if (isAuthenticated) {
      api
        .get('/products/wishlist/')
        .then((res) => {
          const ids = res.data.map((item) => item.id);
          setWishlistIds(ids);
        })
        .catch((err) => {
          console.error('Wishlist fetch error:', err);
        });
    } else {
      Promise.resolve().then(() => setWishlistIds([]));
    }
  }, [isAuthenticated]);

  // ৩. Wishlist Toggle হ্যান্ডলার
  const handleToggleWishlist = async (productId) => {
    if (!isAuthenticated) {
      alert('Please login to use the wishlist!');
      return;
    }

    try {
      const res = await api.post(`/products/wishlist/toggle/${productId}/`);
      if (res.data.in_wishlist) {
        setWishlistIds((prev) => [...prev, productId]);
      } else {
        setWishlistIds((prev) => prev.filter((id) => id !== productId));
      }
    } catch (err) {
      console.error('Wishlist toggle error:', err);
      alert('Failed to update wishlist.');
    }
  };

  if (loading) {
    return <h2 style={{ textAlign: 'center', marginTop: '50px' }}>Loading products...</h2>;
  }

  if (error) {
    return <h2 style={{ textAlign: 'center', color: 'red', marginTop: '50px' }}>{error}</h2>;
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 20px', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2.5rem', fontWeight: '900', letterSpacing: '-1px', marginBottom: '30px' }}>
        VELORA<span style={{ color: '#2563eb' }}>.</span>
      </h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '24px' }}>
        {products.map((product) => {
          const imageUrl = product.image
            ? (product.image.startsWith('http') ? product.image : `http://127.0.0.1:8000${product.image}`)
            : 'https://placehold.co/300x300?text=No+Image';

          const isWishlisted = wishlistIds.includes(product.id);

          return (
            <div
              key={product.id}
              style={{
                border: '1px solid #e2e8f0',
                borderRadius: '12px',
                padding: '16px',
                backgroundColor: '#ffffff',
                boxShadow: '0 4px 12px rgba(0,0,0,0.03)',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}
            >
              <div>
                <img
                  src={imageUrl}
                  alt={product.name}
                  style={{
                    width: '100%',
                    height: '240px',
                    objectFit: 'cover',
                    borderRadius: '8px',
                    backgroundColor: '#f8fafc',
                  }}
                />

                <div style={{ marginTop: '14px', textAlign: 'center' }}>
                  <h3 style={{ margin: '6px 0 4px 0', fontSize: '1.25rem', color: '#1e293b' }}>
                    {product.name}
                  </h3>
                  <p style={{ margin: '0 0 12px 0', fontSize: '0.9rem', color: '#64748b' }}>
                    {product.description || product.category?.name}
                  </p>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                    <span style={{ fontSize: '1.4rem', fontWeight: '800', color: '#059669' }}>
                      ${product.price}
                    </span>
                    <span style={{ fontSize: '0.85rem', color: product.stock > 0 ? '#16a34a' : '#dc2626', fontWeight: '600' }}>
                      Stock: {product.stock}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Add to Cart + Wishlist Button */}
              <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                <button
                  disabled={product.stock <= 0}
                  onClick={() => addToCart && addToCart(product)}
                  style={{
                    flex: 1,
                    padding: '12px 0',
                    backgroundColor: product.stock > 0 ? '#2563eb' : '#cbd5e1',
                    color: '#ffffff',
                    border: 'none',
                    borderRadius: '8px',
                    fontWeight: '700',
                    fontSize: '0.95rem',
                    cursor: product.stock > 0 ? 'pointer' : 'not-allowed',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                  }}
                >
                  {product.stock > 0 ? 'Add to Cart 🛒' : 'Out of Stock'}
                </button>

                <button
                  onClick={() => handleToggleWishlist(product.id)}
                  title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                  style={{
                    padding: '0 14px',
                    backgroundColor: '#ffffff',
                    border: '1px solid #cbd5e1',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontSize: '1.2rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {isWishlisted ? '❤️' : '🤍'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
