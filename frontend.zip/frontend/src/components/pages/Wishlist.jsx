import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function Wishlist({ addToCart }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [removingId, setRemovingId] = useState(null);
  const [error, setError] = useState('');

  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // ---------------------------------------------------------
  // LOAD WISHLIST
  // ---------------------------------------------------------
  const fetchWishlist = async () => {
    try {
      setLoading(true);
      setError('');

      const res = await api.get('/products/wishlist/');

      const data = Array.isArray(res.data)
        ? res.data
        : [];

      setItems(data);
    } catch (err) {
      console.error(
        'Wishlist fetch error:',
        err
      );

      if (err.response?.status === 401) {
        setError(
          'Please login to view your Wishlist.'
        );
      } else {
        setError(
          'Failed to load Wishlist.'
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // ---------------------------------------------------------
  // AUTH CHECK + LOAD
  // ---------------------------------------------------------
  useEffect(() => {
    if (!isAuthenticated) {
      setItems([]);
      setLoading(false);
      return;
    }

    fetchWishlist();
  }, [isAuthenticated]);

  // ---------------------------------------------------------
  // REMOVE FROM WISHLIST
  // ---------------------------------------------------------
  const removeFromWishlist = async (productId) => {
    if (removingId) {
      return;
    }

    try {
      setRemovingId(productId);

      await api.post(
        `/products/wishlist/toggle/${productId}/`
      );

      setItems((prev) =>
        prev.filter(
          (item) => item.id !== productId
        )
      );
    } catch (err) {
      console.error(
        'Remove wishlist error:',
        err
      );

      alert(
        'Failed to remove product from Wishlist.'
      );
    } finally {
      setRemovingId(null);
    }
  };

  // ---------------------------------------------------------
  // MOVE TO CART
  // ---------------------------------------------------------
  const moveToCart = async (product) => {
    if (!product) {
      return;
    }

    if (product.stock <= 0) {
      alert('This product is currently out of stock.');
      return;
    }

    if (addToCart) {
      addToCart(product);
    }

    await removeFromWishlist(product.id);
  };

  // ---------------------------------------------------------
  // NOT LOGGED IN
  // ---------------------------------------------------------
  if (!isAuthenticated && !loading) {
    return (
      <div
        style={{
          maxWidth: '700px',
          margin: '80px auto',
          textAlign: 'center',
          padding: '40px 20px',
        }}
      >
        <div
          style={{
            fontSize: '4rem',
            marginBottom: '15px',
          }}
        >
          ❤️
        </div>

        <h2
          style={{
            marginBottom: '10px',
            color: '#111827',
          }}
        >
          Your Wishlist
        </h2>

        <p
          style={{
            color: '#64748b',
            marginBottom: '25px',
          }}
        >
          Please login to view and manage
          your Wishlist.
        </p>

        <button
          onClick={() =>
            navigate('/login')
          }
          style={{
            padding: '12px 25px',
            background: '#111827',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: '700',
          }}
        >
          Login
        </button>
      </div>
    );
  }

  // ---------------------------------------------------------
  // LOADING
  // ---------------------------------------------------------
  if (loading) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '70px',
        }}
      >
        <h3>Loading your Wishlist...</h3>
      </div>
    );
  }

  // ---------------------------------------------------------
  // ERROR
  // ---------------------------------------------------------
  if (error) {
    return (
      <div
        style={{
          maxWidth: '700px',
          margin: '70px auto',
          textAlign: 'center',
          padding: '30px',
        }}
      >
        <p
          style={{
            color: '#dc2626',
            marginBottom: '20px',
          }}
        >
          {error}
        </p>

        <button
          onClick={fetchWishlist}
          style={{
            padding: '10px 20px',
            border: 'none',
            background: '#111827',
            color: '#fff',
            borderRadius: '7px',
            cursor: 'pointer',
          }}
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div
      style={{
        maxWidth: '1100px',
        margin: '40px auto',
        padding: '20px',
      }}
    >
      {/* HEADER */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '25px',
          borderBottom:
            '1px solid #e5e7eb',
          paddingBottom: '15px',
        }}
      >
        <div>
          <h1
            style={{
              margin: 0,
              color: '#111827',
            }}
          >
            My Wishlist ❤️
          </h1>

          <p
            style={{
              marginTop: '6px',
              color: '#64748b',
            }}
          >
            {items.length}{' '}
            {items.length === 1
              ? 'item'
              : 'items'}{' '}
            saved
          </p>
        </div>

        <Link
          to="/"
          style={{
            textDecoration: 'none',
            color: '#111827',
            border:
              '1px solid #d1d5db',
            padding: '10px 16px',
            borderRadius: '8px',
            fontWeight: '600',
          }}
        >
          Continue Shopping
        </Link>
      </div>

      {/* EMPTY */}
      {items.length === 0 ? (
        <div
          style={{
            textAlign: 'center',
            padding: '80px 20px',
            background: '#fff',
            border:
              '1px solid #e5e7eb',
            borderRadius: '12px',
          }}
        >
          <div
            style={{
              fontSize: '4rem',
              marginBottom: '15px',
            }}
          >
            🤍
          </div>

          <h2
            style={{
              color: '#111827',
              marginBottom: '8px',
            }}
          >
            Your Wishlist is Empty
          </h2>

          <p
            style={{
              color: '#64748b',
              marginBottom: '25px',
            }}
          >
            Save products you love and
            find them here later.
          </p>

          <Link
            to="/"
            style={{
              display: 'inline-block',
              padding: '12px 24px',
              background: '#111827',
              color: '#fff',
              textDecoration: 'none',
              borderRadius: '8px',
              fontWeight: '700',
            }}
          >
            Explore Products
          </Link>
        </div>
      ) : (
        /* ITEMS */
        <div
          style={{
            display: 'grid',
            gridTemplateColumns:
              'repeat(auto-fill, minmax(250px, 1fr))',
            gap: '24px',
          }}
        >
          {items.map((product) => {
            const imageUrl = product.image
              ? product.image.startsWith('http')
                ? product.image
                : `http://127.0.0.1:8000${product.image}`
              : 'https://placehold.co/500x500?text=No+Image';

            const isRemoving =
              removingId === product.id;

            return (
              <div
                key={product.id}
                style={{
                  background: '#fff',
                  border:
                    '1px solid #e2e8f0',
                  borderRadius: '12px',
                  overflow: 'hidden',
                  boxShadow:
                    '0 3px 10px rgba(0,0,0,0.05)',
                }}
              >
                {/* IMAGE */}
                <Link
                  to={`/products/${product.id}`}
                >
                  <img
                    src={imageUrl}
                    alt={product.name}
                    style={{
                      width: '100%',
                      height: '230px',
                      objectFit: 'cover',
                      display: 'block',
                    }}
                  />
                </Link>

                {/* DETAILS */}
                <div
                  style={{
                    padding: '16px',
                  }}
                >
                  <p
                    style={{
                      margin: '0 0 6px',
                      fontSize: '0.75rem',
                      color: '#64748b',
                      textTransform:
                        'uppercase',
                      fontWeight: '700',
                    }}
                  >
                    {product.category?.name ||
                      'Collection'}
                  </p>

                  <Link
                    to={`/products/${product.id}`}
                    style={{
                      textDecoration:
                        'none',
                      color: '#111827',
                    }}
                  >
                    <h3
                      style={{
                        margin:
                          '0 0 8px',
                        fontSize:
                          '1.05rem',
                      }}
                    >
                      {product.name}
                    </h3>
                  </Link>

                  <p
                    style={{
                      margin:
                        '0 0 12px',
                      fontSize:
                        '1.15rem',
                      fontWeight: '800',
                      color: '#111827',
                    }}
                  >
                    $
                    {parseFloat(
                      product.price
                    ).toFixed(2)}
                  </p>

                  <p
                    style={{
                      margin:
                        '0 0 15px',
                      color:
                        product.stock > 0
                          ? '#16a34a'
                          : '#dc2626',
                      fontSize:
                        '0.85rem',
                      fontWeight: '600',
                    }}
                  >
                    {product.stock > 0
                      ? `${product.stock} available`
                      : 'Out of stock'}
                  </p>

                  {/* ACTIONS */}
                  <div
                    style={{
                      display: 'flex',
                      gap: '8px',
                    }}
                  >
                    <button
                      type="button"
                      onClick={() =>
                        moveToCart(product)
                      }
                      disabled={
                        product.stock <=
                          0 ||
                        isRemoving
                      }
                      style={{
                        flex: 1,
                        padding: '10px',
                        border: 'none',
                        borderRadius:
                          '7px',
                        background:
                          product.stock >
                            0 &&
                          !isRemoving
                            ? '#111827'
                            : '#d1d5db',
                        color: '#fff',
                        fontWeight:
                          '700',
                        cursor:
                          product.stock >
                            0 &&
                          !isRemoving
                            ? 'pointer'
                            : 'not-allowed',
                      }}
                    >
                      {isRemoving
                        ? 'Removing...'
                        : product.stock >
                          0
                        ? 'Move to Cart'
                        : 'Out of Stock'}
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        removeFromWishlist(
                          product.id
                        )
                      }
                      disabled={isRemoving}
                      title="Remove from Wishlist"
                      style={{
                        width: '45px',
                        border:
                          '1px solid #fecdd3',
                        borderRadius:
                          '7px',
                        background:
                          '#fff1f2',
                        color: '#be123c',
                        cursor:
                          isRemoving
                            ? 'wait'
                            : 'pointer',
                        fontSize:
                          '1.1rem',
                      }}
                    >
                      {isRemoving
                        ? '...'
                        : '❤️'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}