import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';

export default function Checkout({ cart, setCart }) {
  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);

  const [showNewAddressForm, setShowNewAddressForm] = useState(false);

  const [newAddress, setNewAddress] = useState({
    house: '',
    road: '',
    thana: '',
    district: 'Dhaka',
    division: 'Dhaka',
    zip_code: '',
  });

  const [paymentMethod, setPaymentMethod] = useState('cod');

  const [loading, setLoading] = useState(false);
  const [addressLoading, setAddressLoading] = useState(true);

  const [error, setError] = useState('');

  const navigate = useNavigate();

  // ---------------------------------------------------------
  // Calculate total amount
  // ---------------------------------------------------------

  const totalAmount = (cart || []).reduce(
    (sum, item) =>
      sum + Number(item.price || 0) * Number(item.quantity || 0),
    0
  );

  // ---------------------------------------------------------
  // Fetch saved addresses
  // ---------------------------------------------------------

  async function fetchAddresses() {
    try {
      setAddressLoading(true);
      setError('');

      const res = await api.get('/auth/addresses/');

      const addressList = Array.isArray(res.data)
        ? res.data
        : [];

      setAddresses(addressList);

      if (addressList.length > 0) {
        const defaultAddr =
          addressList.find((address) => address.is_default) ||
          addressList[0];

        setSelectedAddressId(defaultAddr.id);
        setShowNewAddressForm(false);
      } else {
        setShowNewAddressForm(true);
      }
    } catch (err) {
      console.error('Failed to load addresses:', err);

      setError(
        err.response?.data?.error ||
        'Failed to load saved addresses.'
      );
    } finally {
      setAddressLoading(false);
    }
  }

  // ---------------------------------------------------------
  // Load addresses when Checkout page opens
  // ---------------------------------------------------------

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetchAddresses();
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  // ---------------------------------------------------------
  // Handle new address field changes
  // ---------------------------------------------------------

  const handleAddressChange = (field, value) => {
    setNewAddress((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  // ---------------------------------------------------------
  // Save new address
  // ---------------------------------------------------------

  const handleSaveAddress = async (e) => {
    e.preventDefault();

    setError('');

    try {
      const res = await api.post(
        '/auth/addresses/',
        newAddress
      );

      const savedAddress = res.data;

      setAddresses((previous) => [
        ...previous,
        savedAddress,
      ]);

      setSelectedAddressId(savedAddress.id);

      setShowNewAddressForm(false);

      setNewAddress({
        house: '',
        road: '',
        thana: '',
        district: 'Dhaka',
        division: 'Dhaka',
        zip_code: '',
      });
    } catch (err) {
      console.error('Address Save Error:', err);

      setError(
        err.response?.data?.error ||
        'Failed to save address.'
      );
    }
  };

  // ---------------------------------------------------------
  // Place Order
  // ---------------------------------------------------------

  const handlePlaceOrder = async () => {
    setError('');

    // Check cart
    if (!cart || cart.length === 0) {
      setError('Your cart is empty.');
      return;
    }

    // Check address
    if (!selectedAddressId) {
      setError(
        'Please select or add a delivery address.'
      );
      return;
    }

    // Check total
    if (totalAmount <= 0) {
      setError('Invalid order amount.');
      return;
    }

    setLoading(true);

    const payload = {
      address_id: selectedAddressId,

      payment_method: paymentMethod,

      items: cart.map((item) => ({
        id: item.id,
        quantity: item.quantity,
      })),
    };

    try {
      console.log('Creating order:', payload);

      const res = await api.post(
        '/orders/create/',
        payload
      );

      console.log('Order response:', res.data);

      // -----------------------------------------------------
      // STRIPE PAYMENT
      // -----------------------------------------------------

      if (
        res.data.payment_method === 'card' &&
        res.data.stripe_url
      ) {
        // Clear local cart before redirecting.
        setCart([]);

        // Redirect to Stripe Checkout.
        window.location.href = res.data.stripe_url;

        return;
      }

      // -----------------------------------------------------
      // COD ORDER
      // -----------------------------------------------------

      if (
        res.data.payment_method === 'cod' ||
        !res.data.stripe_url
      ) {
        setCart([]);

        alert('Order placed successfully!');

        navigate('/');
      }
    } catch (err) {
      console.error(
        'Order Placement Error:',
        err
      );

      const backendError =
        err.response?.data?.error;

      if (backendError) {
        setError(backendError);
      } else if (err.response?.data?.detail) {
        setError(err.response.data.detail);
      } else {
        setError(
          'Failed to place order. Please try again.'
        );
      }
    } finally {
      setLoading(false);
    }
  };

  // ---------------------------------------------------------
  // Empty cart
  // ---------------------------------------------------------

  if (!cart || cart.length === 0) {
    return (
      <div
        style={{
          maxWidth: '800px',
          margin: '60px auto',
          padding: '30px',
          textAlign: 'center',
          background: '#fff',
          borderRadius: '10px',
          border: '1px solid #e2e8f0',
        }}
      >
        <h2>Your Cart is Empty</h2>

        <p
          style={{
            color: '#64748b',
            marginBottom: '20px',
          }}
        >
          Add some products to your cart before
          proceeding to checkout.
        </p>

        <button
          type="button"
          onClick={() => navigate('/')}
          style={{
            padding: '12px 20px',
            background: '#0f172a',
            color: '#fff',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontWeight: 'bold',
          }}
        >
          Continue Shopping
        </button>
      </div>
    );
  }

  // ---------------------------------------------------------
  // UI
  // ---------------------------------------------------------

  return (
    <div
      style={{
        maxWidth: '800px',
        margin: '30px auto',
        padding: '24px',
        background: '#fff',
        borderRadius: '8px',
        border: '1px solid #e2e8f0',
      }}
    >
      <h2
        style={{
          textAlign: 'center',
          marginBottom: '24px',
        }}
      >
        Checkout
      </h2>

      {/* =====================================================
          ERROR MESSAGE
      ====================================================== */}

      {error && (
        <div
          style={{
            background: '#fee2e2',
            color: '#b91c1c',
            padding: '12px',
            borderRadius: '6px',
            marginBottom: '20px',
            textAlign: 'center',
          }}
        >
          {error}
        </div>
      )}

      {/* =====================================================
          1. DELIVERY ADDRESS
      ====================================================== */}

      <div
        style={{
          border: '1px solid #f1f5f9',
          padding: '18px',
          borderRadius: '8px',
          marginBottom: '20px',
          background: '#f8fafc',
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '12px',
          }}
        >
          <h3
            style={{
              margin: 0,
              fontSize: '1.1rem',
            }}
          >
            1. Delivery Address
          </h3>

          <button
            type="button"
            onClick={() => {
              setError('');

              setShowNewAddressForm(
                (previous) => !previous
              );
            }}
            style={{
              padding: '6px 12px',
              fontSize: '0.85rem',
              cursor: 'pointer',
              background: '#e2e8f0',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {showNewAddressForm
              ? 'Select Existing'
              : '+ Add New Address'}
          </button>
        </div>

        {/* Address Loading */}

        {addressLoading ? (
          <p>Loading addresses...</p>
        ) : showNewAddressForm ? (
          /* =================================================
             NEW ADDRESS FORM
          ================================================== */

          <form
            onSubmit={handleSaveAddress}
            style={{
              display: 'grid',
              gap: '10px',
            }}
          >
            <input
              placeholder="House / Flat No."
              required
              value={newAddress.house}
              onChange={(e) =>
                handleAddressChange(
                  'house',
                  e.target.value
                )
              }
              style={{
                padding: '8px',
                border: '1px solid #cbd5e1',
                borderRadius: '4px',
              }}
            />

            <input
              placeholder="Road / Area"
              required
              value={newAddress.road}
              onChange={(e) =>
                handleAddressChange(
                  'road',
                  e.target.value
                )
              }
              style={{
                padding: '8px',
                border: '1px solid #cbd5e1',
                borderRadius: '4px',
              }}
            />

            <div
              style={{
                display: 'grid',
                gridTemplateColumns:
                  '1fr 1fr 1fr',
                gap: '10px',
              }}
            >
              <input
                placeholder="Thana"
                required
                value={newAddress.thana}
                onChange={(e) =>
                  handleAddressChange(
                    'thana',
                    e.target.value
                  )
                }
                style={{
                  padding: '8px',
                  border:
                    '1px solid #cbd5e1',
                  borderRadius: '4px',
                }}
              />

              <input
                placeholder="District"
                required
                value={newAddress.district}
                onChange={(e) =>
                  handleAddressChange(
                    'district',
                    e.target.value
                  )
                }
                style={{
                  padding: '8px',
                  border:
                    '1px solid #cbd5e1',
                  borderRadius: '4px',
                }}
              />

              <input
                placeholder="ZIP Code"
                value={newAddress.zip_code}
                onChange={(e) =>
                  handleAddressChange(
                    'zip_code',
                    e.target.value
                  )
                }
                style={{
                  padding: '8px',
                  border:
                    '1px solid #cbd5e1',
                  borderRadius: '4px',
                }}
              />
            </div>

            <button
              type="submit"
              style={{
                padding: '10px',
                background: '#0f172a',
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: 'bold',
              }}
            >
              Save & Use Address
            </button>
          </form>
        ) : addresses.length === 0 ? (
          /* =================================================
             NO ADDRESS
          ================================================== */

          <p>
            No saved address found. Please add a
            new address.
          </p>
        ) : (
          /* =================================================
             EXISTING ADDRESSES
          ================================================== */

          <div
            style={{
              display: 'grid',
              gap: '10px',
            }}
          >
            {addresses.map((addr) => (
              <label
                key={addr.id}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '10px',
                  padding: '10px',
                  border:
                    selectedAddressId === addr.id
                      ? '2px solid #2563eb'
                      : '1px solid #cbd5e1',
                  borderRadius: '6px',
                  background: '#fff',
                  cursor: 'pointer',
                }}
              >
                <input
                  type="radio"
                  name="selected_address"
                  checked={
                    selectedAddressId ===
                    addr.id
                  }
                  onChange={() =>
                    setSelectedAddressId(
                      addr.id
                    )
                  }
                  style={{
                    marginTop: '4px',
                  }}
                />

                <div>
                  <strong>
                    {addr.house},{' '}
                    {addr.road}
                  </strong>

                  <p
                    style={{
                      margin: '2px 0',
                      color: '#64748b',
                      fontSize: '0.9rem',
                    }}
                  >
                    {addr.thana},{' '}
                    {addr.district}

                    {addr.zip_code
                      ? ` - ${addr.zip_code}`
                      : ''}
                  </p>
                </div>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* =====================================================
          2. ORDER REVIEW
      ====================================================== */}

      <div
        style={{
          border: '1px solid #f1f5f9',
          padding: '18px',
          borderRadius: '8px',
          marginBottom: '20px',
        }}
      >
        <h3
          style={{
            margin: 0,
            marginBottom: '14px',
            fontSize: '1.1rem',
          }}
        >
          2. Order Items Review
        </h3>

        {cart.map((item) => (
          <div
            key={item.id}
            style={{
              display: 'flex',
              justifyContent:
                'space-between',
              marginBottom: '10px',
            }}
          >
            <span>
              {item.name} (x
              {item.quantity})
            </span>

            <span
              style={{
                fontWeight: 'bold',
              }}
            >
              $
              {(
                Number(item.price || 0) *
                Number(item.quantity || 0)
              ).toFixed(2)}
            </span>
          </div>
        ))}

        <hr
          style={{
            border: 'none',
            borderTop:
              '1px solid #e2e8f0',
            margin: '14px 0',
          }}
        />

        <div
          style={{
            display: 'flex',
            justifyContent:
              'space-between',
            fontSize: '1.25rem',
            fontWeight: 'bold',
          }}
        >
          <span>Total:</span>

          <span>
            ${totalAmount.toFixed(2)}
          </span>
        </div>
      </div>

      {/* =====================================================
          3. PAYMENT METHOD
      ====================================================== */}

      <div
        style={{
          marginBottom: '24px',
        }}
      >
        <h3
          style={{
            fontSize: '1.1rem',
            marginBottom: '10px',
          }}
        >
          3. Payment Method
        </h3>

        {/* COD */}

        <label
          style={{
            marginRight: '20px',
            cursor: 'pointer',
          }}
        >
          <input
            type="radio"
            name="payment"
            value="cod"
            checked={
              paymentMethod === 'cod'
            }
            onChange={(e) =>
              setPaymentMethod(
                e.target.value
              )
            }
          />{' '}
          Cash on Delivery (COD)
        </label>

        {/* Stripe */}

        <label
          style={{
            cursor: 'pointer',
          }}
        >
          <input
            type="radio"
            name="payment"
            value="card"
            checked={
              paymentMethod === 'card'
            }
            onChange={(e) =>
              setPaymentMethod(
                e.target.value
              )
            }
          />{' '}
          Online Card / Stripe
        </label>
      </div>

      {/* =====================================================
          PLACE ORDER BUTTON
      ====================================================== */}

      <button
        type="button"
        onClick={handlePlaceOrder}
        disabled={
          loading ||
          cart.length === 0 ||
          !selectedAddressId
        }
        style={{
          width: '100%',
          padding: '14px',
          background:
            loading ||
            cart.length === 0 ||
            !selectedAddressId
              ? '#94a3b8'
              : '#0f172a',
          color: '#fff',
          border: 'none',
          borderRadius: '6px',
          fontWeight: 'bold',
          fontSize: '1.1rem',
          cursor:
            loading ||
            cart.length === 0 ||
            !selectedAddressId
              ? 'not-allowed'
              : 'pointer',
        }}
      >
        {loading
          ? 'Processing Order...'
          : paymentMethod === 'card'
          ? `Proceed to Stripe Payment ($${totalAmount.toFixed(
              2
            )})`
          : `Place Order ($${totalAmount.toFixed(
              2
            )})`}
      </button>
    </div>
  );
}