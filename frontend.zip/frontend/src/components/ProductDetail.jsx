import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function ProductDetail({ onAddToCart }) {
  const { id } = useParams();

  const { isAuthenticated } = useAuth();

  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [added, setAdded] = useState(false);

  const [isWishlisted, setIsWishlisted] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);

  // ---------------------------------------------------------
  // LOAD PRODUCT
  // ---------------------------------------------------------
  useEffect(() => {
    const loadProduct = async () => {
      try {
        setLoading(true);
        setError('');

        const res = await api.get(`/products/${id}/`);

        setProduct(res.data);
      } catch (err) {
        console.error('Product detail error:', err);

        setError(
          'Product not found or failed to load.'
        );
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [id]);

  // ---------------------------------------------------------
  // CHECK WISHLIST STATUS
  // ---------------------------------------------------------
  useEffect(() => {
    const checkWishlist = async () => {
      if (!isAuthenticated) {
        setIsWishlisted(false);
        return;
      }

      try {
        const res = await api.get('/products/wishlist/');

        const exists = Array.isArray(res.data)
          ? res.data.some(
              (item) => item.id === Number(id)
            )
          : false;

        setIsWishlisted(exists);
      } catch (err) {
        console.error(
          'Wishlist status error:',
          err
        );

        setIsWishlisted(false);
      }
    };

    checkWishlist();
  }, [id, isAuthenticated]);

  // ---------------------------------------------------------
  // QUANTITY
  // ---------------------------------------------------------
  const handleQuantityChange = (delta) => {
    setQuantity((prev) => {
      const updated = prev + delta;

      if (updated < 1) {
        return 1;
      }

      if (product && updated > product.stock) {
        return product.stock;
      }

      return updated;
    });
  };

  // ---------------------------------------------------------
  // ADD TO CART
  // ---------------------------------------------------------
  const handleAdd = () => {
    if (!product || product.stock <= 0) {
      return;
    }

    for (let i = 0; i < quantity; i++) {
      onAddToCart(product);
    }

    setAdded(true);

    setTimeout(() => {
      setAdded(false);
    }, 2000);
  };

  // ---------------------------------------------------------
  // WISHLIST TOGGLE
  // ---------------------------------------------------------
  const handleWishlist = async () => {
    if (!isAuthenticated) {
      alert('Please login first to use Wishlist.');
      return;
    }

    if (wishlistLoading) {
      return;
    }

    try {
      setWishlistLoading(true);

      const res = await api.post(
        `/products/wishlist/toggle/${product.id}/`
      );

      setIsWishlisted(
        Boolean(res.data.in_wishlist)
      );
    } catch (err) {
      console.error(
        'Wishlist toggle error:',
        err
      );

      if (err.response?.status === 401) {
        alert(
          'Your login session has expired. Please login again.'
        );
      } else {
        alert('Failed to update Wishlist.');
      }
    } finally {
      setWishlistLoading(false);
    }
  };

  // ---------------------------------------------------------
  // STATES
  // ---------------------------------------------------------
  if (loading) {
    return (
      <p
        style={{
          textAlign: 'center',
          marginTop: '50px',
        }}
      >
        Loading product details...
      </p>
    );
  }

  if (error) {
    return (
      <p
        style={{
          textAlign: 'center',
          color: '#dc2626',
          marginTop: '50px',
        }}
      >
        {error}
      </p>
    );
  }

  if (!product) {
    return null;
  }

  // ---------------------------------------------------------
  // IMAGE URL
  // ---------------------------------------------------------
  const imageUrl = product.image
    ? product.image.startsWith('http')
      ? product.image
      : `http://127.0.0.1:8000${product.image}`
    : null;

  return (
    <div
      style={{
        maxWidth: '1000px',
        margin: '40px auto',
        background: '#fff',
        padding: '30px',
        borderRadius: '12px',
        boxShadow:
          '0 2px 10px rgba(0,0,0,0.05)',
      }}
    >
      {/* BACK */}
      <Link
        to="/"
        style={{
          textDecoration: 'none',
          color: '#6366f1',
          fontWeight: '600',
          marginBottom: '25px',
          display: 'inline-block',
        }}
      >
        &larr; Back to Shop
      </Link>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns:
            'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '40px',
          alignItems: 'start',
        }}
      >
        {/* IMAGE */}
        <div
          style={{
            borderRadius: '10px',
            overflow: 'hidden',
            backgroundColor: '#f9fafb',
            height: '400px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={product.name}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          ) : (
            <span
              style={{
                color: '#9ca3af',
              }}
            >
              No Image Available
            </span>
          )}
        </div>

        {/* INFO */}
        <div>
          <span
            style={{
              fontSize: '0.8rem',
              color: '#6b7280',
              textTransform: 'uppercase',
              fontWeight: '700',
            }}
          >
            {product.category?.name ||
              'General'}
          </span>

          <h1
            style={{
              margin: '8px 0 12px',
              fontSize: '2rem',
              color: '#111827',
            }}
          >
            {product.name}
          </h1>

          <p
            style={{
              fontSize: '1.6rem',
              fontWeight: '800',
              color: '#111827',
              marginBottom: '18px',
            }}
          >
            ${parseFloat(product.price).toFixed(2)}
          </p>

          <p
            style={{
              color: '#4b5563',
              lineHeight: '1.7',
              marginBottom: '20px',
            }}
          >
            {product.description ||
              'No description provided for this product.'}
          </p>

          {/* STOCK */}
          <p
            style={{
              fontSize: '0.9rem',
              marginBottom: '20px',
            }}
          >
            <strong>Availability: </strong>

            {product.stock > 0 ? (
              <span
                style={{
                  color: '#15803d',
                  fontWeight: '600',
                }}
              >
                In Stock ({product.stock} available)
              </span>
            ) : (
              <span
                style={{
                  color: '#b91c1c',
                  fontWeight: '600',
                }}
              >
                Out of Stock
              </span>
            )}
          </p>

          {/* QUANTITY */}
          {product.stock > 0 && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                marginBottom: '20px',
              }}
            >
              <span
                style={{
                  fontWeight: '600',
                  color: '#374151',
                }}
              >
                Quantity:
              </span>

              <button
                onClick={() =>
                  handleQuantityChange(-1)
                }
                style={{
                  width: '34px',
                  height: '34px',
                  border:
                    '1px solid #d1d5db',
                  background: '#fff',
                  borderRadius: '6px',
                  cursor: 'pointer',
                }}
              >
                -
              </button>

              <span
                style={{
                  fontWeight: '700',
                  minWidth: '25px',
                  textAlign: 'center',
                }}
              >
                {quantity}
              </span>

              <button
                onClick={() =>
                  handleQuantityChange(1)
                }
                style={{
                  width: '34px',
                  height: '34px',
                  border:
                    '1px solid #d1d5db',
                  background: '#fff',
                  borderRadius: '6px',
                  cursor: 'pointer',
                }}
              >
                +
              </button>
            </div>
          )}

          {/* ADD TO CART */}
          <button
            onClick={handleAdd}
            disabled={product.stock <= 0}
            style={{
              width: '100%',
              padding: '13px',
              backgroundColor:
                product.stock > 0
                  ? '#111827'
                  : '#e5e7eb',
              color:
                product.stock > 0
                  ? '#ffffff'
                  : '#9ca3af',
              border: 'none',
              borderRadius: '8px',
              fontWeight: '700',
              cursor:
                product.stock > 0
                  ? 'pointer'
                  : 'not-allowed',
              fontSize: '1rem',
              marginBottom: '10px',
            }}
          >
            {added
              ? 'Added to Cart!'
              : product.stock > 0
              ? 'Add to Cart'
              : 'Out of Stock'}
          </button>

          {/* WISHLIST */}
          <button
            type="button"
            onClick={handleWishlist}
            disabled={wishlistLoading}
            style={{
              width: '100%',
              padding: '13px',
              backgroundColor: isWishlisted
                ? '#fff1f2'
                : '#ffffff',
              color: isWishlisted
                ? '#be123c'
                : '#111827',
              border:
                '1px solid #d1d5db',
              borderRadius: '8px',
              fontWeight: '700',
              cursor: wishlistLoading
                ? 'wait'
                : 'pointer',
              fontSize: '1rem',
            }}
          >
            {wishlistLoading
              ? 'Updating...'
              : isWishlisted
              ? '❤️ Remove from Wishlist'
              : '🤍 Add to Wishlist'}
          </button>

          {/* VIEW WISHLIST */}
          {isAuthenticated && (
            <Link
              to="/wishlist"
              style={{
                display: 'block',
                textAlign: 'center',
                marginTop: '15px',
                color: '#6366f1',
                fontWeight: '600',
                textDecoration: 'none',
              }}
            >
              View My Wishlist →
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
