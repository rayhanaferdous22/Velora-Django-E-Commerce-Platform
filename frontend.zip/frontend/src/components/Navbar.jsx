import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar({ cartCount = 0, user = null, onLogout }) {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/?q=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      navigate('/');
    }
  };

  return (
    <header style={styles.header}>
      {/* Top Notification Strip */}
      <div style={styles.topStrip}>
        <span>COMPLIMENTARY SHIPPING & SAMPLES WITH ALL ORDERS</span>
      </div>

      {/* Main Luxury Navbar */}
      <div style={styles.navContainer}>
        <div style={styles.navInner}>
          {/* Logo */}
          <Link to="/" style={styles.logo}>
            VELORA
          </Link>

          {/* Search Bar */}
          <form onSubmit={handleSearch} style={styles.searchBox}>
            <span style={{ opacity: 0.5, fontSize: '0.9rem' }}>🔍</span>
            <input
              type="text"
              placeholder="Search products, brands, essentials..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </form>

          {/* Right Actions */}
          <div style={styles.actions}>
            <Link to="/wishlist" style={styles.authLink}>Wishlist</Link>
            {user ? (
              <div style={styles.userWrapper}>
                <span style={styles.userText}>Hi, {user.username}</span>
                {user.is_staff && (
                  <Link to="/dashboard/orders" style={styles.adminTag}>
                    Admin
                  </Link>
                )}
                <button onClick={onLogout} style={styles.logoutBtn}>
                  Logout
                </button>
              </div>
            ) : (
              <div style={styles.authGroup}>
                <Link to="/login" style={styles.authLink}>Sign In</Link>
                <Link to="/register" style={styles.joinBtn}>Join Us</Link>
              </div>
            )}

            {/* Bag Icon */}
            <Link to="/cart" style={styles.bagLink}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#000000" strokeWidth="1.8">
                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <path d="M16 10a4 4 0 0 1-8 0"></path>
              </svg>
              {cartCount > 0 && <span style={styles.bagBadge}>{cartCount}</span>}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

const styles = {
  header: {
    backgroundColor: '#ffffff',
    borderBottom: '1px solid #000000',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  topStrip: {
    backgroundColor: '#000000',
    color: '#ffffff',
    textAlign: 'center',
    padding: '7px 10px',
    fontSize: '0.72rem',
    fontWeight: '600',
    letterSpacing: '1.5px',
  },
  navContainer: {
    maxWidth: '1300px',
    margin: '0 auto',
    padding: '14px 24px',
  },
  navInner: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '30px',
  },
  logo: {
    fontSize: '1.85rem',
    fontWeight: '900',
    letterSpacing: '2px',
    color: '#000000',
    textDecoration: 'none',
    fontFamily: 'system-ui, -apple-system, sans-serif',
  },
  searchBox: {
    flex: 1,
    maxWidth: '560px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    backgroundColor: '#f5f5f5',
    border: '1px solid #e0e0e0',
    borderRadius: '4px',
    padding: '8px 14px',
  },
  searchInput: {
    border: 'none',
    outline: 'none',
    backgroundColor: 'transparent',
    width: '100%',
    fontSize: '0.88rem',
  },
  actions: {
    display: 'flex',
    alignItems: 'center',
    gap: '18px',
  },
  authGroup: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  },
  authLink: {
    color: '#000000',
    textDecoration: 'none',
    fontSize: '0.88rem',
    fontWeight: '600',
  },
  joinBtn: {
    backgroundColor: '#000000',
    color: '#ffffff',
    textDecoration: 'none',
    padding: '6px 14px',
    borderRadius: '4px',
    fontSize: '0.85rem',
    fontWeight: '600',
  },
  userWrapper: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  userText: {
    fontSize: '0.88rem',
    fontWeight: '600',
  },
  adminTag: {
    backgroundColor: '#000000',
    color: '#ffffff',
    padding: '2px 8px',
    borderRadius: '3px',
    fontSize: '0.75rem',
    textDecoration: 'none',
    fontWeight: 'bold',
  },
  logoutBtn: {
    background: 'none',
    border: 'none',
    color: '#dc2626',
    cursor: 'pointer',
    fontSize: '0.85rem',
    fontWeight: '600',
  },
  bagLink: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
    textDecoration: 'none',
  },
  bagBadge: {
    position: 'absolute',
    top: '-6px',
    right: '-8px',
    backgroundColor: '#000000',
    color: '#ffffff',
    borderRadius: '50%',
    width: '18px',
    height: '18px',
    fontSize: '0.7rem',
    fontWeight: 'bold',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
