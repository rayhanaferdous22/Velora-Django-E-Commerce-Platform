import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function ProductList({ onAddToCart }) {
  const [products, setProducts] = useState([]);
  const [wishlistIds, setWishlistIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [wishlistLoading, setWishlistLoading] = useState({});
  const [error, setError] = useState('');

  const { isAuthenticated } = useAuth();

  // ---------------------------------------------------------
  // LOAD PRODUCTS
  // ---------------------------------------------------------
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);

        const res = await api.get('/products/');

        const data = Array.isArray(res.data)
          ? res.data
          : res.data.results || [];

        setProducts(data);
        setError('');
      } catch (err) {
        console.error('Product Fetch Error:', err);
        setError(
          'Products could not be loaded. Make sure Django server is running.'
        );
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  // ---------------------------------------------------------
  // LOAD CURRENT USER WISHLIST
  // ---------------------------------------------------------
  useEffect(() => {
    const loadWishlist = async () => {
      if (!isAuthenticated) {
        setWishlistIds([]);
        return;
      }

      try {
        const res = await api.get('/products/wishlist/');

        const ids = Array.isArray(res.data)
          ? res.data.map((item) => item.id)
          : [];

        setWishlistIds(ids);
      } catch (err) {
        console.error('Wishlist Load Error:', err);

        if (err.response?.status === 401) {
          setWishlistIds([]);
        }
      }
    };

    loadWishlist();
  }, [isAuthenticated]);

  // ---------------------------------------------------------
  // TOGGLE WISHLIST
  // ---------------------------------------------------------
  const handleWishlistToggle = async (productId) => {
    if (!isAuthenticated) {
      alert('Please login first to use Wishlist.');
      return;
    }

    if (wishlistLoading[productId]) return;

    try {
      setWishlistLoading((prev) => ({
        ...prev,
        [productId]: true,
      }));

      const res = await api.post(
        `/products/wishlist/toggle/${productId}/`
      );

      const isWishlisted = res.data.in_wishlist;

      if (isWishlisted) {
        setWishlistIds((prev) => {
          if (prev.includes(productId)) {
            return prev;
          }

          return [...prev, productId];
        });
      } else {
        setWishlistIds((prev) =>
          prev.filter((id) => id !== productId)
        );
      }
    } catch (err) {
      console.error('Wishlist Toggle Error:', err);

      if (err.response?.status === 401) {
        alert('Please login first to use Wishlist.');
      } else {
        alert('Failed to update Wishlist.');
      }
    } finally {
      setWishlistLoading((prev) => ({
        ...prev,
        [productId]: false,
      }));
    }
  };

  // ---------------------------------------------------------
  // LOADING
  // ---------------------------------------------------------
  if (loading) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '60px',
          fontSize: '1.1rem',
        }}
      >
        Loading products...
      </div>
    );
  }

  // ---------------------------------------------------------
  // ERROR
  // ---------------------------------------------------------
  if (error) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '60px',
          color: '#dc2626',
        }}
      >
        <h3>{error}</h3>
        <p>Please check that Django is running.</p>
      </div>
    );
  }

  return (
    <div
      style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '30px 20px',
      }}
    >
      {/* HEADER */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '25px',
        }}
      >
        <div>
          <h1
            style={{
              margin: 0,
              color: '#111827',
              fontSize: '2rem',
            }}
          >
            Velora Collection
          </h1>

          <p
            style={{
              color: '#64748b',
              marginTop: '6px',
            }}
          >
            Discover products you love.
          </p>
        </div>

        <Link
          to="/wishlist"
          style={{
            textDecoration: 'none',
            color: '#111827',
            fontWeight: '700',
            border: '1px solid #d1d5db',
            padding: '10px 16px',
            borderRadius: '8px',
            background: '#fff',
          }}
        >
          ❤️ Wishlist
        </Link>
      </div>

      {/* PRODUCTS */}
      {products.length === 0 ? (
        <div
          style={{
            textAlign: 'center',
            padding: '50px',
            color: '#64748b',
          }}
        >
          No products available.
        </div>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns:
              'repeat(auto-fill, minmax(250px, 1fr))',
            gap: '24px',
          }}
        >
          {products.map((product) => {
            const imageUrl = product.image
              ? product.image.startsWith('http')
                ? product.image
                : `http://127.0.0.1:8000${product.image}`
              : 'https://placehold.co/600x400?text=No+Image';

            const isWishlisted =
              wishlistIds.includes(product.id);

            const isWishlistLoading =
              wishlistLoading[product.id];

            return (
              <div
                key={product.id}
                style={{
                  background: '#fff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '12px',
                  overflow: 'hidden',
                  boxShadow:
                    '0 4px 12px rgba(0,0,0,0.05)',
                  display: 'flex',
                  flexDirection: 'column',
                }}
              >
                {/* IMAGE */}
                <div
                  style={{
                    position: 'relative',
                    height: '230px',
                    background: '#f8fafc',
                  }}
                >
                  <Link
                    to={`/products/${product.id}`}
                    style={{
                      display: 'block',
                      width: '100%',
                      height: '100%',
                    }}
                  >
                    <img
                      src={imageUrl}
                      alt={product.name}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                    />
                  </Link>

                  {/* WISHLIST HEART */}
                  <button
                    type="button"
                    onClick={() =>
                      handleWishlistToggle(product.id)
                    }
                    disabled={isWishlistLoading}
                    title={
                      isWishlisted
                        ? 'Remove from Wishlist'
                        : 'Add to Wishlist'
                    }
                    style={{
                      position: 'absolute',
                      top: '12px',
                      right: '12px',
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      border: '1px solid #e5e7eb',
                      background: '#ffffff',
                      cursor: isWishlistLoading
                        ? 'wait'
                        : 'pointer',
                      fontSize: '1.2rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow:
                        '0 2px 8px rgba(0,0,0,0.1)',
                    }}
                  >
                    {isWishlisted ? '❤️' : '🤍'}
                  </button>

                  {product.stock <= 0 && (
                    <span
                      style={{
                        position: 'absolute',
                        left: '12px',
                        top: '12px',
                        background: '#111827',
                        color: '#fff',
                        padding: '5px 10px',
                        borderRadius: '20px',
                        fontSize: '0.75rem',
                        fontWeight: '700',
                      }}
                    >
                      SOLD OUT
                    </span>
                  )}
                </div>

                {/* DETAILS */}
                <div
                  style={{
                    padding: '16px',
                    flex: 1,
                  }}
                >
                  <p
                    style={{
                      margin: '0 0 6px',
                      color: '#64748b',
                      fontSize: '0.75rem',
                      textTransform: 'uppercase',
                      fontWeight: '700',
                    }}
                  >
                    {product.category?.name || 'Collection'}
                  </p>

                  <Link
                    to={`/products/${product.id}`}
                    style={{
                      textDecoration: 'none',
                      color: '#111827',
                    }}
                  >
                    <h3
                      style={{
                        margin: '0 0 8px',
                        fontSize: '1.05rem',
                      }}
                    >
                      {product.name}
                    </h3>
                  </Link>

                  <p
                    style={{
                      color: '#64748b',
                      fontSize: '0.85rem',
                      lineHeight: '1.5',
                      minHeight: '42px',
                    }}
                  >
                    {product.description ||
                      'No description available.'}
                  </p>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginTop: '12px',
                    }}
                  >
                    <span
                      style={{
                        fontSize: '1.2rem',
                        fontWeight: '800',
                        color: '#111827',
                      }}
                    >
                      ${parseFloat(product.price).toFixed(2)}
                    </span>

                    <span
                      style={{
                        fontSize: '0.8rem',
                        color:
                          product.stock > 0
                            ? '#16a34a'
                            : '#dc2626',
                        fontWeight: '600',
                      }}
                    >
                      {product.stock > 0
                        ? `${product.stock} available`
                        : 'Out of stock'}
                    </span>
                  </div>
                </div>

                {/* ACTIONS */}
                <div
                  style={{
                    display: 'flex',
                    gap: '8px',
                    padding: '0 16px 16px',
                  }}
                >
                  <button
                    type="button"
                    onClick={() =>
                      onAddToCart &&
                      onAddToCart(product)
                    }
                    disabled={product.stock <= 0}
                    style={{
                      flex: 1,
                      padding: '11px',
                      border: 'none',
                      borderRadius: '8px',
                      background:
                        product.stock > 0
                          ? '#111827'
                          : '#d1d5db',
                      color: '#fff',
                      fontWeight: '700',
                      cursor:
                        product.stock > 0
                          ? 'pointer'
                          : 'not-allowed',
                    }}
                  >
                    {product.stock > 0
                      ? 'Add to Cart 🛒'
                      : 'Out of Stock'}
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleWishlistToggle(product.id)
                    }
                    disabled={isWishlistLoading}
                    style={{
                      width: '48px',
                      border: '1px solid #d1d5db',
                      borderRadius: '8px',
                      background: isWishlisted
                        ? '#fff1f2'
                        : '#fff',
                      cursor: isWishlistLoading
                        ? 'wait'
                        : 'pointer',
                      fontSize: '1.1rem',
                    }}
                  >
                    {isWishlisted ? '❤️' : '🤍'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
