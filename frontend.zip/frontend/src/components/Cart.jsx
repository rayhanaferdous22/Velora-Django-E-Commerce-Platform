import { Link, useNavigate } from 'react-router-dom';

export default function Cart({ cart, setCart }) {
  const navigate = useNavigate();

  const updateQuantity = (id, delta) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  const removeItem = (id) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 20px', background: '#fff', borderRadius: '12px', marginTop: '30px' }}>
        <h2 style={{ color: '#111827' }}>Your Cart is Empty</h2>
        <p style={{ color: '#6b7280', marginBottom: '20px' }}>Explore the store and add items to your cart.</p>
        <Link to="/" style={{ padding: '10px 20px', backgroundColor: '#111827', color: '#fff', textDecoration: 'none', borderRadius: '6px', fontWeight: '600' }}>
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '900px', margin: '30px auto', background: '#fff', padding: '24px', borderRadius: '12px', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}>
      <h1 style={{ fontSize: '1.75rem', marginBottom: '20px', color: '#111827' }}>Shopping Cart</h1>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '2px solid #e5e7eb', textAlign: 'left' }}>
            <th style={{ padding: '12px 0' }}>Product</th>
            <th style={{ padding: '12px 0', textAlign: 'center' }}>Quantity</th>
            <th style={{ padding: '12px 0', textAlign: 'right' }}>Price</th>
            <th style={{ padding: '12px 0', textAlign: 'right' }}>Total</th>
            <th style={{ padding: '12px 0', textAlign: 'center' }}>Remove</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item) => (
            <tr key={item.id} style={{ borderBottom: '1px solid #f3f4f6' }}>
              <td style={{ padding: '14px 0', fontWeight: '600', color: '#111827' }}>{item.name}</td>
              <td style={{ padding: '14px 0', textAlign: 'center' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
                  <button onClick={() => updateQuantity(item.id, -1)} style={qtyBtnStyle}>-</button>
                  <span style={{ fontWeight: '600' }}>{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} style={qtyBtnStyle}>+</button>
                </div>
              </td>
              <td style={{ padding: '14px 0', textAlign: 'right' }}>${parseFloat(item.price).toFixed(2)}</td>
              <td style={{ padding: '14px 0', textAlign: 'right', fontWeight: '700' }}>
                ${(item.price * item.quantity).toFixed(2)}
              </td>
              <td style={{ padding: '14px 0', textAlign: 'center' }}>
                <button onClick={() => removeItem(item.id)} style={{ background: 'none', border: 'none', color: '#dc2626', cursor: 'pointer', fontWeight: 'bold' }}>
                  ✕
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Cart Summary */}
      <div style={{ marginTop: '30px', display: 'flex', justifyContent: 'flex-end' }}>
        <div style={{ width: '300px', background: '#f9fafb', padding: '20px', borderRadius: '8px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px', fontSize: '1.1rem' }}>
            <span>Subtotal:</span>
            <strong>${subtotal.toFixed(2)}</strong>
          </div>
          <button
            onClick={() => navigate('/checkout')}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: '#111827',
              color: '#fff',
              border: 'none',
              borderRadius: '6px',
              fontWeight: '700',
              cursor: 'pointer',
              fontSize: '1rem',
            }}
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
}

const qtyBtnStyle = {
  width: '26px',
  height: '26px',
  border: '1px solid #d1d5db',
  background: '#fff',
  borderRadius: '4px',
  cursor: 'pointer',
  fontWeight: 'bold',
};