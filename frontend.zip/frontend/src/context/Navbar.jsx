import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar({ cartCount = 0, user = null, onLogout }) {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <header style={styles.header}>
      {/* Top Banner Announcement */}
      <div style={styles.topAnnouncement}>
        <span>✨ FREE EXPRESS SHIPPING ON ALL ORDERS OVER $75 • USE CODE: <strong>VELORA2026</strong></span>
      </div>

      {/* Main Clean Navigation */}
      <div style={styles.mainNav}>
        <div style={styles.container}>
          {/* Brand Logo */}
          <Link to="/" style={styles.logo}>
            VELORA<span style={styles.logoDot}>.</span>
          </Link>

          {/* Minimal Search Bar */}
          <form onSubmit={handleSearch} style={styles.searchForm}>
            <span style={styles.searchIcon}>🔍</span>
            <input
              type="text"
              placeholder="Search modern clothing, cosmetics, electronics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </form>

          {/* User Links & Cart */}
          <div style={styles.actions}>
            {user ? (
              <div style={styles.userSection}>
                <span style={styles.userName}>Hello, {user.username}</span>
                {user.is_staff && (
                  <Link to="/dashboard/orders" style={styles.adminBadge}>
                    Admin
                  </Link>
                )}
                <button onClick={onLogout} style={styles.logoutBtn}>
                  Logout
                </button>
              </div>
            ) : (
              <div style={styles.authLinks}>
                <Link to="/login" style={styles.authText}>Sign In</Link>
                <Link to="/register" style={styles.signUpBtn}>Join Us</Link>
              </div>
            )}

            {/* Modern Cart Button */}
            <Link to="/cart" style={styles.cartBtn}>
              <div style={styles.cartIconWrapper}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                  <line x1="3" y1="6" x2="21" y2="6"></line>
                  <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                {cartCount > 0 && <span style={styles.cartBadge}>{cartCount}</span>}
              </div>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

const styles = {
  header: {
    position: 'sticky',
    top: 0,
    zIndex: 100,
    backgroundColor: '#ffffff',
    borderBottom: '1px solid #f1f5f9',
    boxShadow: '0 2px 10px rgba(0,0,0,0.03)',
  },
  topAnnouncement: {
    backgroundColor: '#0f172a',
    color: '#ffffff',
    fontSize: '0.75rem',
    letterSpacing: '1px',
    textAlign: 'center',
    padding: '8px 12px',
    fontWeight: '500',
  },
  mainNav: {
    padding: '14px 0',
  },
  container: {
    maxWidth: '1280px',
    margin: '0 auto',
    padding: '0 24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '30px',
  },
  logo: {
    color: '#0f172a',
    fontSize: '1.75rem',
    fontWeight: '900',
    letterSpacing: '-1px',
    textDecoration: 'none',
    display: 'flex',
    alignItems: 'baseline',
  },
  logoDot: {
    color: '#6366f1',
    fontSize: '2rem',
  },
  searchForm: {
    flex: 1,
    maxWidth: '550px',
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: '100px',
    padding: '8px 18px',
    border: '1px solid #e2e8f0',
    transition: 'all 0.2s',
  },
  searchIcon: {
    fontSize: '0.9rem',
    marginRight: '8px',
    opacity: 0.6,
  },
  searchInput: {
    flex: 1,
    border: 'none',
    outline: 'none',
    backgroundColor: 'transparent',
    fontSize: '0.9rem',
    color: '#1e293b',
  },
  actions: {
    display: 'flex',
    alignItems: 'center',
    gap: '20px',
  },
  authLinks: {
    display: 'flex',
    alignItems: 'center',
    gap: '14px',
  },
  authText: {
    color: '#334155',
    textDecoration: 'none',
    fontSize: '0.9rem',
    fontWeight: '600',
  },
  signUpBtn: {
    backgroundColor: '#0f172a',
    color: '#ffffff',
    padding: '8px 18px',
    borderRadius: '100px',
    textDecoration: 'none',
    fontSize: '0.85rem',
    fontWeight: '600',
    transition: 'all 0.2s',
  },
  userSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  },
  userName: {
    fontSize: '0.9rem',
    fontWeight: '600',
    color: '#334155',
  },
  adminBadge: {
    backgroundColor: '#ede9fe',
    color: '#6366f1',
    padding: '4px 10px',
    borderRadius: '100px',
    fontSize: '0.75rem',
    fontWeight: '700',
    textDecoration: 'none',
  },
  logoutBtn: {
    background: 'none',
    border: 'none',
    color: '#ef4444',
    fontSize: '0.85rem',
    fontWeight: '600',
    cursor: 'pointer',
  },
  cartBtn: {
    textDecoration: 'none',
    color: '#0f172a',
  },
  cartIconWrapper: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
  },
  cartBadge: {
    position: 'absolute',
    top: '-6px',
    right: '-8px',
    backgroundColor: '#6366f1',
    color: '#ffffff',
    borderRadius: '50%',
    width: '18px',
    height: '18px',
    fontSize: '0.7rem',
    fontWeight: 'bold',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
