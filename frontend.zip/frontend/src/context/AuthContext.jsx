import { createContext, useContext, useState } from 'react';
import api from '../services/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {

  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [token, setToken] = useState(
    () => localStorage.getItem('token') || ''
  );


  // ============================================================
  // LOGIN
  // ============================================================

  const login = async (username, password) => {

    const res = await api.post(
      '/auth/login/',
      {
        username,
        password,
      }
    );

    setToken(res.data.token);
    setUser(res.data.user);

    localStorage.setItem('token', res.data.token);
    localStorage.setItem(
      'user',
      JSON.stringify(res.data.user)
    );

    return res.data;
  };


  // ============================================================
  // REGISTER
  // ============================================================

  const register = async (username, email, password) => {

    const res = await api.post(
      '/auth/register/',
      {
        username,
        email,
        password,
      }
    );

    setToken(res.data.token);
    setUser(res.data.user);

    localStorage.setItem('token', res.data.token);
    localStorage.setItem(
      'user',
      JSON.stringify(res.data.user)
    );

    return res.data;
  };


  // ============================================================
  // LOGOUT
  // ============================================================

  const logout = () => {

    setToken('');
    setUser(null);

    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };


  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}


export const useAuth = () => useContext(AuthContext);
