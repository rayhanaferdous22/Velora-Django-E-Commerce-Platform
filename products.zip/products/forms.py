from django import forms

from category.models import Category, SubCategory

from .models import Product, ProductImage, ProductVariant, Review


class ProductForm(forms.ModelForm):
    """Used for both Add Product and Edit Product — slug/SKU are derived
    automatically in Product.save() so they aren't shown here."""

    class Meta:
        model = Product
        fields = [
            'category', 'subcategory', 'name', 'short_description', 'description',
            'price', 'discount_price', 'stock', 'low_stock_threshold', 'image',
            'is_featured', 'is_active',
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'short_description': forms.TextInput(attrs={'maxlength': 255}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = Category.objects.filter(is_active=True)
        self.fields['subcategory'].queryset = SubCategory.objects.filter(is_active=True)
        self.fields['subcategory'].required = False

    def clean(self):
        cleaned_data = super().clean()
        price = cleaned_data.get('price')
        discount_price = cleaned_data.get('discount_price')
        if discount_price is not None and price is not None and discount_price >= price:
            self.add_error(
                'discount_price', 'Discount price must be lower than the regular price.'
            )
        subcategory = cleaned_data.get('subcategory')
        category = cleaned_data.get('category')
        if subcategory and category and subcategory.category_id != category.id:
            self.add_error('subcategory', 'This subcategory does not belong to the selected category.')
        return cleaned_data


class ProductImageForm(forms.ModelForm):
    """Used to upload additional gallery images for a product."""

    class Meta:
        model = ProductImage
        fields = ['image', 'alt_text', 'is_primary']


class ProductVariantForm(forms.ModelForm):
    """Used to add Color/Size variants to a product from the admin CRUD."""

    class Meta:
        model = ProductVariant
        fields = ['color', 'size', 'extra_price', 'stock', 'is_active']

    def clean(self):
        cleaned_data = super().clean()
        if not cleaned_data.get('color') and not cleaned_data.get('size'):
            raise forms.ValidationError('Set at least a color or a size for this variant.')
        return cleaned_data


class ReviewForm(forms.ModelForm):
    """Used by customers to leave a rating + comment on a product they've
    purchased (see products.services.can_review)."""

    rating = forms.ChoiceField(
        choices=[(i, f'{i} star{"s" if i != 1 else ""}') for i in range(5, 0, -1)],
        widget=forms.RadioSelect,
    )

    class Meta:
        model = Review
        fields = ['rating', 'comment']
        widgets = {
            'comment': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Share your thoughts (optional)'}),
        }
