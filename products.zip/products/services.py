"""Business logic for products, kept out of views.py."""

from django.db.models import Q

from .models import Product


def get_active_products():
    return Product.objects.filter(is_active=True).select_related('category')


def get_products_by_category(category):
    return get_active_products().filter(category=category)


def get_product_by_slug(slug):
    return get_active_products().filter(slug=slug).first()


def search_products(query):
    if not query:
        return get_active_products()
    return get_active_products().filter(
        Q(name__icontains=query) | Q(description__icontains=query)
    )


def is_purchasable(product, quantity=1):
    """Centralized stock check reused by cart/orders services."""
    return product.is_active and product.stock >= quantity
