"""Staff-only product management, mounted at /admin/products/ (kept separate
from Django's own /admin/ site, and included BEFORE it in
velora_project/urls.py so this prefix is matched first)."""

from django.urls import path

from . import views

app_name = 'products'

urlpatterns = [
    path('', views.product_manage_list, name='list'),
    path('add/', views.product_create, name='add'),
    path('<slug:slug>/edit/', views.product_update, name='edit'),
    path('<slug:slug>/delete/', views.product_delete, name='delete'),

    path('<slug:slug>/images/add/', views.product_image_add, name='image_add'),
    path('<slug:slug>/images/<int:image_id>/delete/', views.product_image_delete, name='image_delete'),

    path('<slug:slug>/variants/add/', views.product_variant_add, name='variant_add'),
    path('<slug:slug>/variants/<int:variant_id>/delete/', views.product_variant_delete, name='variant_delete'),
]
