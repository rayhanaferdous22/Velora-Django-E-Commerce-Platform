from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    path('', views.ProductListAPIView.as_view(), name='api_product_list'),
    path('<int:pk>/', views.ProductDetailAPIView.as_view(), name='api_product_detail'),
    path('categories/', views.CategoryListAPIView.as_view(), name='api_category_list'),
    
    # Wishlist Endpoints
    path('wishlist/', views.api_wishlist_list, name='api_wishlist_list'),
    path('wishlist/toggle/<int:product_id>/', views.api_wishlist_toggle, name='api_wishlist_toggle'),
]