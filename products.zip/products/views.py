from category.models import Category
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from . import services
from .models import Product, Review, Wishlist
from .serializers import CategorySerializer, ProductSerializer


# ===========================================================================
# 1. Django Template Views (For Server-Rendered HTML)
# ===========================================================================

def product_list(request):
    query = request.GET.get('q', '').strip()
    category_slug = request.GET.get('category', '').strip()

    products = (
        Product.objects
        .filter(is_active=True)
        .select_related('category')
        .order_by('-created_at')
    )

    if query:
        products = products.filter(name__icontains=query)

    if category_slug:
        products = products.filter(
            category__slug=category_slug,
            category__is_active=True,
        )

    categories = Category.objects.filter(is_active=True).order_by('name')

    return render(
        request,
        'products/product_list.html',
        {
            'products': products,
            'categories': categories,
            'query': query,
            'selected_category': category_slug,
        },
    )


def product_detail(request, slug):
    product = get_object_or_404(
        Product,
        slug=slug,
        is_active=True,
    )

    reviews = (
        Review.objects
        .filter(product=product)
        .select_related('user')
        .order_by('-created_at')
    )

    user_review = None

    if request.user.is_authenticated:
        user_review = Review.objects.filter(
            product=product,
            user=request.user,
        ).first()

    return render(
        request,
        'products/product_detail.html',
        {
            'product': product,
            'reviews': reviews,
            'user_review': user_review,
        },
    )


@login_required
def submit_review(request, slug):
    if request.method != 'POST':
        return redirect(
            'products:detail',
            slug=slug,
        )

    product = get_object_or_404(
        Product,
        slug=slug,
        is_active=True,
    )

    existing_review = Review.objects.filter(
        product=product,
        user=request.user,
    ).first()

    if existing_review:
        messages.error(
            request,
            'You have already reviewed this product.',
        )
        return redirect(
            'products:detail',
            slug=product.slug,
        )

    rating = request.POST.get('rating', '').strip()
    comment = request.POST.get('comment', '').strip()

    try:
        rating = int(rating)
    except (TypeError, ValueError):
        messages.error(
            request,
            'Please select a valid rating.',
        )
        return redirect(
            'products:detail',
            slug=product.slug,
        )

    if rating < 1 or rating > 5:
        messages.error(
            request,
            'Rating must be between 1 and 5.',
        )
        return redirect(
            'products:detail',
            slug=product.slug,
        )

    if not comment:
        messages.error(
            request,
            'Please write a review before submitting.',
        )
        return redirect(
            'products:detail',
            slug=product.slug,
        )

    Review.objects.create(
        product=product,
        user=request.user,
        rating=rating,
        comment=comment,
    )

    messages.success(
        request,
        'Your review has been submitted successfully.',
    )

    return redirect(
        'products:detail',
        slug=product.slug,
    )


# ===========================================================================
# 2. REST API Views (For React Frontend)
# ===========================================================================

class ProductListAPIView(generics.ListAPIView):
    serializer_class = ProductSerializer

    def get_queryset(self):
        queryset = Product.objects.filter(is_active=True).select_related('category')
        category_slug = self.request.query_params.get('category', None)
        search_query = self.request.query_params.get('search', None) or self.request.query_params.get('q', None)

        if category_slug:
            queryset = queryset.filter(category__slug=category_slug)
        if search_query:
            queryset = queryset.filter(name__icontains=search_query)

        return queryset.order_by('-created_at')


class ProductDetailAPIView(generics.RetrieveAPIView):
    queryset = Product.objects.filter(is_active=True)
    serializer_class = ProductSerializer
    lookup_field = 'pk'


class CategoryListAPIView(generics.ListAPIView):
    queryset = Category.objects.filter(is_active=True)
    serializer_class = CategorySerializer


# ===========================================================================
# 3. Wishlist API Views
# ===========================================================================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_wishlist_list(request):
    wishlist_items = Wishlist.objects.filter(user=request.user).select_related('product')
    products = [item.product for item in wishlist_items]
    serializer = ProductSerializer(products, many=True, context={'request': request})
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['GET', 'POST'])
def api_wishlist_toggle(request, product_id):
    # ইউজার লগইন না করা থাকলে হ্যান্ডেল করা
    if not request.user.is_authenticated:
        # যদি HTML টেমপ্লেট থেকে ফর্ম সাবমিট হয় (next প্যারামিটার থাকে)
        next_url = request.POST.get('next') or request.GET.get('next')
        if next_url:
            messages.warning(request, 'Please log in to add items to your wishlist.')
            return redirect(f"/accounts/login/?next={next_url}")
        return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return Response({'error': 'Product not found.'}, status=status.HTTP_404_NOT_FOUND)

    wishlist_item = Wishlist.objects.filter(user=request.user, product=product).first()

    if wishlist_item:
        wishlist_item.delete()
        in_wishlist = False
        message = 'Removed from wishlist.'
    else:
        Wishlist.objects.create(user=request.user, product=product)
        in_wishlist = True
        message = 'Added to wishlist.'

    # HTML Form রিডাইরেক্ট সাপোর্ট
    next_url = request.POST.get('next') or request.GET.get('next')
    if next_url:
        messages.success(request, message)
        return redirect(next_url)

    return Response({
        'message': message,
        'in_wishlist': in_wishlist
    }, status=status.HTTP_200_OK if not in_wishlist else status.HTTP_201_CREATED)