from django import template

register = template.Library()


@register.filter
def stars(rating):
    """Render a numeric rating (e.g. 4.3) as a filled/empty star string."""
    if rating is None:
        return ''
    full = int(round(float(rating)))
    full = max(0, min(5, full))
    return '★' * full + '☆' * (5 - full)


@register.filter
def get_item(dictionary, key):
    """Template helper: dictionary.get(key) — Django templates can't call
    .get() with a variable key directly."""
    if not dictionary:
        return None
    return dictionary.get(key)