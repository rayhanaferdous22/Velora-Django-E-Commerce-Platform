"""Business logic for the shopping cart, kept out of views.py."""

from django.core.exceptions import ValidationError

from products.services import is_purchasable

from .models import Cart, CartItem


def get_or_create_cart(user):
    cart, _ = Cart.objects.get_or_create(user=user)
    return cart


def add_to_cart(user, product, quantity=1):
    if quantity < 1:
        raise ValidationError('Quantity must be at least 1.')
    if not is_purchasable(product, quantity):
        raise ValidationError('This product is not available in the requested quantity.')

    cart = get_or_create_cart(user)
    item, created = CartItem.objects.get_or_create(
        cart=cart, product=product, defaults={'quantity': quantity}
    )
    if not created:
        item.quantity += quantity
        item.save()
    return item


def update_cart_item(user, product_id, quantity):
    cart = get_or_create_cart(user)
    item = cart.items.filter(product_id=product_id).first()
    if not item:
        raise ValidationError('That item is not in your cart.')
    if quantity < 1:
        item.delete()
        return None
    if not is_purchasable(item.product, quantity):
        raise ValidationError('Not enough stock for the requested quantity.')
    item.quantity = quantity
    item.save()
    return item


def remove_from_cart(user, product_id):
    cart = get_or_create_cart(user)
    cart.items.filter(product_id=product_id).delete()


def get_cart_items(user):
    return get_or_create_cart(user).items.select_related('product')


def get_cart_total(user):
    return sum(item.subtotal for item in get_cart_items(user))


def clear_cart(user):
    get_or_create_cart(user).items.all().delete()
