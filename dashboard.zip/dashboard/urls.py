from django.urls import path
from . import views

app_name = "dashboard"

urlpatterns = [
    # Dashboard Home
    path("", views.admin_dashboard, name="admin_dashboard"),
    path("home/", views.admin_dashboard, name="home"),

    # Orders Management
    path("orders/", views.manage_orders, name="manage_orders"),
    path("orders/<int:order_id>/", views.manage_order_detail, name="manage_order_detail"),
    path("orders/<int:order_id>/detail/", views.manage_order_detail, name="order_detail"),
    path("orders/<int:order_id>/status/", views.update_status, name="update_status"),
    path("orders/<int:order_id>/tracking/", views.update_tracking, name="update_tracking"),

    # Products Management
    path("products/", views.manage_products, name="manage_products"),
    path("products/create/", views.create_product, name="create_product"),
    path("products/<int:product_id>/edit/", views.edit_product, name="edit_product"),
    path("products/<int:product_id>/delete/", views.delete_product, name="delete_product"),

    # Categories Management
    path("categories/", views.manage_categories, name="manage_categories"),
    path("categories/create/", views.create_category, name="create_category"),
    path("categories/<int:category_id>/edit/", views.edit_category, name="edit_category"),
    path("categories/<int:category_id>/delete/", views.delete_category, name="delete_category"),
]