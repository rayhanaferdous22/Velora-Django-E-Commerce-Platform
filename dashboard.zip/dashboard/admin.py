# No models to register — this app only exposes a staff-only
# aggregate-stats view (see views.py / services.py).
