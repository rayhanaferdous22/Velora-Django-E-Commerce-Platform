from datetime import datetime

from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import admin_required
from category.models import Category
from orders.models import Order
from products.models import Product

from . import services


@admin_required
def admin_dashboard(request):
    stats = services.get_dashboard_stats()
    recent_orders = services.get_recent_orders()
    low_stock_products = services.get_low_stock_products()

    return render(
        request,
        "dashboard/admin_dashboard.html",
        {
            "stats": stats,
            "recent_orders": recent_orders,
            "low_stock_products": low_stock_products,
        },
    )


# ---------------------------------------------------------------------------
# Admin Manage Orders
# ---------------------------------------------------------------------------

@admin_required
def manage_orders(request):
    status = request.GET.get("status", "")
    query = request.GET.get("q", "")

    # --- ACCEPT / DELIVER / REJECT / DELETE ACTION HANDLER ---
    if request.method == "POST":
        order_id = request.POST.get("order_id")
        action = request.POST.get("action")
        target_order = get_object_or_404(Order, pk=order_id)

        if action == "accept":
            target_order.status = Order.STATUS_PROCESSING
            target_order.save(update_fields=["status", "updated_at"])
            messages.success(
                request,
                f"Order #{target_order.pk} accepted and is now Processing.",
            )

        elif action == "deliver":
            target_order.status = Order.STATUS_DELIVERED
            target_order.save(update_fields=["status", "updated_at"])
            messages.success(
                request,
                f"Order #{target_order.pk} marked as Delivered!",
            )

        elif action == "reject":
            target_order.status = Order.STATUS_CANCELLED
            target_order.save(update_fields=["status", "updated_at"])
            messages.warning(
                request,
                f"Order #{target_order.pk} has been rejected.",
            )

        elif action == "delete":
            order_pk = target_order.pk
            target_order.delete()
            messages.success(
                request,
                f"Order #{order_pk} has been permanently deleted.",
            )

        return redirect("dashboard:manage_orders")

    # --- QUERY ORDERS ---
    orders = (
        Order.objects
        .select_related("user", "shipping_address")
        .prefetch_related("items")
        .order_by("-created_at")
    )

    if status:
        orders = orders.filter(status=status)

    if query:
        if query.isdigit():
            orders = orders.filter(pk=int(query))
        else:
            orders = orders.filter(user__username__icontains=query)

    counts = {
        "all": Order.objects.count(),
        "pending": Order.objects.filter(status=Order.STATUS_PENDING).count(),
        "paid": Order.objects.filter(status=Order.STATUS_PAID).count(),
        "processing": Order.objects.filter(status=Order.STATUS_PROCESSING).count(),
        "delivered": Order.objects.filter(status=Order.STATUS_DELIVERED).count(),
        "cancelled": Order.objects.filter(status=Order.STATUS_CANCELLED).count(),
    }

    return render(
        request,
        "dashboard/orders/list.html",
        {
            "orders": orders,
            "status_choices": Order.STATUS_CHOICES,
            "selected_status": status,
            "query": query,
            "counts": counts,
        },
    )


@admin_required
def manage_order_detail(request, order_id):
    order = (
        Order.objects
        .select_related("user", "shipping_address")
        .prefetch_related("items__product")
        .filter(pk=order_id)
        .first()
    )

    if not order:
        raise Http404("Order not found.")

    if request.method == "POST":
        new_status = request.POST.get("status")
        valid_statuses = dict(Order.STATUS_CHOICES)

        if new_status in valid_statuses:
            order.status = new_status
            order.save(update_fields=["status", "updated_at"])
            messages.success(
                request,
                f'Order #{order.pk} status updated to "{order.get_status_display()}".',
            )
            return redirect("dashboard:manage_order_detail", order_id=order.pk)
        else:
            messages.error(request, "Invalid status selected.")

    return render(
        request,
        "dashboard/orders/detail.html",
        {
            "order": order,
            "status_choices": Order.STATUS_CHOICES,
        },
    )


@admin_required
def update_status(request, order_id):
    order = get_object_or_404(Order, pk=order_id)

    if request.method == "POST":
        new_status = request.POST.get("status")
        valid_statuses = dict(Order.STATUS_CHOICES)

        if new_status not in valid_statuses:
            messages.error(request, "Invalid order status.")
        else:
            order.status = new_status
            order.save(update_fields=["status", "updated_at"])
            messages.success(
                request,
                f"Order #{order.id} status updated to {order.get_status_display()}.",
            )
            return redirect("dashboard:manage_order_detail", order_id=order.id)

    return render(
        request,
        "dashboard/orders/update_status.html",
        {
            "order": order,
            "status_choices": Order.STATUS_CHOICES,
        },
    )


# ---------------------------------------------------------------------------
# Tracking
# ---------------------------------------------------------------------------

@admin_required
def update_tracking(request, order_id):
    order = get_object_or_404(Order, pk=order_id)

    if request.method == "POST":
        tracking_number = request.POST.get("tracking_number", "").strip()
        tracking_url = request.POST.get("tracking_url", "").strip()
        estimated_delivery = request.POST.get("estimated_delivery", "").strip()

        order.tracking_number = tracking_number
        order.tracking_url = tracking_url

        if estimated_delivery:
            try:
                order.estimated_delivery = datetime.strptime(
                    estimated_delivery, "%Y-%m-%d"
                ).date()
            except ValueError:
                messages.error(request, "Invalid estimated delivery date.")
                return render(
                    request,
                    "dashboard/orders/tracking.html",
                    {"order": order},
                )
        else:
            order.estimated_delivery = None

        order.save(
            update_fields=[
                "tracking_number",
                "tracking_url",
                "estimated_delivery",
                "updated_at",
            ]
        )

        messages.success(
            request,
            f"Tracking information updated for Order #{order.id}.",
        )
        return redirect("dashboard:manage_order_detail", order_id=order.id)

    return render(
        request,
        "dashboard/orders/tracking.html",
        {"order": order},
    )


# ---------------------------------------------------------------------------
# Admin Manage Products
# ---------------------------------------------------------------------------

@admin_required
def manage_products(request):
    query = request.GET.get("q", "").strip()
    category_id = request.GET.get("category", "").strip()

    products = (
        Product.objects
        .select_related("category")
        .order_by("-created_at")
    )

    if query:
        products = products.filter(name__icontains=query)

    if category_id:
        products = products.filter(category_id=category_id)

    categories = Category.objects.all().order_by("name")

    return render(
        request,
        "dashboard/products/list.html",
        {
            "products": products,
            "categories": categories,
            "query": query,
            "selected_category": category_id,
        },
    )


@admin_required
def create_product(request):
    categories = Category.objects.all()

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        category_id = request.POST.get("category")
        description = request.POST.get("description", "").strip()
        price = request.POST.get("price", "").strip()
        stock = request.POST.get("stock", "").strip()
        is_active = request.POST.get("is_active") == "on"
        image = request.FILES.get("image")

        if not name:
            messages.error(request, "Product name is required.")
        elif not category_id:
            messages.error(request, "Please select a category.")
        elif not price:
            messages.error(request, "Product price is required.")
        elif not stock:
            messages.error(request, "Product stock is required.")
        else:
            try:
                category = get_object_or_404(Category, pk=category_id)
                product = Product.objects.create(
                    category=category,
                    name=name,
                    description=description,
                    price=price,
                    stock=stock,
                    image=image,
                    is_active=is_active,
                )
                messages.success(
                    request,
                    f'Product "{product.name}" created successfully.',
                )
                return redirect("dashboard:manage_products")
            except (ValueError, ValidationError):
                messages.error(
                    request,
                    "Please enter valid product information.",
                )

    return render(
        request,
        "dashboard/products/form.html",
        {
            "categories": categories,
            "product": None,
        },
    )


@admin_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    categories = Category.objects.all()

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        category_id = request.POST.get("category")
        description = request.POST.get("description", "").strip()
        price = request.POST.get("price", "").strip()
        stock = request.POST.get("stock", "").strip()
        is_active = request.POST.get("is_active") == "on"
        image = request.FILES.get("image")

        if not name:
            messages.error(request, "Product name is required.")
        elif not category_id:
            messages.error(request, "Please select a category.")
        elif not price:
            messages.error(request, "Product price is required.")
        elif not stock:
            messages.error(request, "Product stock is required.")
        else:
            try:
                category = get_object_or_404(Category, pk=category_id)
                product.category = category
                product.name = name
                product.description = description
                product.price = price
                product.stock = stock
                product.is_active = is_active

                if image:
                    product.image = image

                product.save()
                messages.success(
                    request,
                    f'Product "{product.name}" updated successfully.',
                )
                return redirect("dashboard:manage_products")
            except (ValueError, ValidationError):
                messages.error(
                    request,
                    "Please enter valid product information.",
                )

    return render(
        request,
        "dashboard/products/form.html",
        {
            "categories": categories,
            "product": product,
        },
    )


@admin_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    if request.method == "POST":
        product_name = product.name
        try:
            product.delete()
            messages.success(
                request,
                f'Product "{product_name}" deleted successfully.',
            )
        except Exception:
            product.is_active = False
            product.save(update_fields=["is_active"])
            messages.warning(
                request,
                f'Product "{product_name}" has existing order records, so it was deactivated instead of deleted.',
            )
        return redirect("dashboard:manage_products")

    return render(
        request,
        "dashboard/products/delete.html",
        {"product": product},
    )


# ---------------------------------------------------------------------------
# Admin Manage Categories
# ---------------------------------------------------------------------------

@admin_required
def manage_categories(request):
    query = request.GET.get("q", "").strip()
    categories = Category.objects.select_related("parent").all()

    if query:
        categories = categories.filter(name__icontains=query)

    return render(
        request,
        "dashboard/categories/list.html",
        {
            "categories": categories,
            "query": query,
        },
    )


@admin_required
def create_category(request):
    parent_categories = Category.objects.filter(parent__isnull=True)

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        parent_id = request.POST.get("parent")
        description = request.POST.get("description", "").strip()
        is_active = request.POST.get("is_active") == "on"
        image = request.FILES.get("image")

        if not name:
            messages.error(request, "Category name is required.")
        else:
            parent = None
            if parent_id:
                parent = Category.objects.filter(pk=parent_id).first()

            Category.objects.create(
                name=name,
                parent=parent,
                description=description,
                image=image,
                is_active=is_active,
            )
            messages.success(
                request,
                f'Category "{name}" created successfully.',
            )
            return redirect("dashboard:manage_categories")

    return render(
        request,
        "dashboard/categories/form.html",
        {
            "parent_categories": parent_categories,
            "category": None,
        },
    )


@admin_required
def edit_category(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    parent_categories = Category.objects.filter(parent__isnull=True).exclude(pk=category.id)

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        parent_id = request.POST.get("parent")
        description = request.POST.get("description", "").strip()
        is_active = request.POST.get("is_active") == "on"
        image = request.FILES.get("image")

        if not name:
            messages.error(request, "Category name is required.")
        else:
            category.name = name
            category.parent = (
                Category.objects.filter(pk=parent_id).first()
                if parent_id
                else None
            )
            category.description = description
            category.is_active = is_active

            if image:
                category.image = image

            category.save()
            messages.success(
                request,
                f'Category "{category.name}" updated successfully.',
            )
            return redirect("dashboard:manage_categories")

    return render(
        request,
        "dashboard/categories/form.html",
        {
            "parent_categories": parent_categories,
            "category": category,
        },
    )


@admin_required
def delete_category(request, category_id):
    category = get_object_or_404(Category, pk=category_id)

    if request.method == "POST":
        category_name = category.name
        try:
            category.delete()
            messages.success(
                request,
                f'Category "{category_name}" deleted successfully.',
            )
        except Exception:
            category.is_active = False
            category.save(update_fields=["is_active"])
            messages.warning(
                request,
                f'Category "{category_name}" contains products, so it was deactivated instead of deleted.',
            )
        return redirect("dashboard:manage_categories")

    return render(
        request,
        "dashboard/categories/delete.html",
        {"category": category},
    )