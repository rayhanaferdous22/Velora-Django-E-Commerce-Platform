"""Business logic for the admin dashboard, kept out of views.py."""

from django.contrib.auth.models import User
from django.db.models import Sum

from orders.models import Order
from products.models import Product


def get_dashboard_stats():
    total_revenue = (
        Order.objects.filter(
            status__in=[
                Order.STATUS_PAID,
                Order.STATUS_DELIVERED,
            ]
        )
        .aggregate(total=Sum('total_amount'))['total']
        or 0
    )

    return {
        'total_users': User.objects.count(),
        'total_products': Product.objects.filter(is_active=True).count(),
        'total_orders': Order.objects.count(),
        'pending_orders': Order.objects.filter(
            status=Order.STATUS_PENDING
        ).count(),
        'total_revenue': total_revenue,

        # Your Product model does not have low_stock_threshold.
        # So stock <= 5 is treated as low stock.
        'low_stock_count': get_low_stock_products().count(),

        'out_of_stock_count': Product.objects.filter(
            is_active=True,
            stock=0
        ).count(),
    }


def get_recent_orders(limit=10):
    return (
        Order.objects
        .select_related('user')
        .order_by('-created_at')[:limit]
    )


def get_low_stock_products(limit=10):
    """
    Return active products that have low stock.

    Since the current Product model does not contain
    a low_stock_threshold field, stock <= 5 is used
    as the low-stock condition.
    """

    return (
        Product.objects
        .filter(
            is_active=True,
            stock__gt=0,
            stock__lte=5,
        )
        .order_by('stock')[:limit]
    )