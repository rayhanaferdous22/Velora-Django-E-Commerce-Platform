from django.urls import path
from . import views

app_name = 'orders'

urlpatterns = [
    # ============================================================
    # 1. REST API Endpoints (For React Frontend)
    # ============================================================
    # Handles: POST /api/orders/create/ and POST /api/orders/checkout/
    path('create/', views.api_create_order, name='api_create_order'),
    path('checkout/api/', views.api_create_order, name='api_checkout'),

    # ============================================================
    # 2. Django Backend / Template Routes
    # ============================================================
    path('checkout/', views.checkout, name='checkout'),
    path('', views.order_list, name='list'),
    path('<int:order_id>/', views.order_detail, name='detail'),
    path('<int:order_id>/cancel/', views.cancel_order, name='cancel'),
]