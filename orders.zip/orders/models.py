from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone

from accounts.models import Address
from products.models import Product


class Coupon(models.Model):
    DISCOUNT_PERCENTAGE = 'percentage'
    DISCOUNT_FIXED = 'fixed'

    DISCOUNT_TYPE_CHOICES = (
        (DISCOUNT_PERCENTAGE, 'Percentage'),
        (DISCOUNT_FIXED, 'Fixed Amount'),
    )

    code = models.CharField(max_length=30, unique=True)

    discount_type = models.CharField(
        max_length=10,
        choices=DISCOUNT_TYPE_CHOICES,
        default=DISCOUNT_PERCENTAGE,
    )

    discount_value = models.DecimalField(
        max_digits=10,
        decimal_places=2,
    )

    min_purchase_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        help_text='Order must reach at least this amount before delivery for the coupon to apply.',
    )

    max_discount_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )

    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()

    usage_limit = models.PositiveIntegerField(default=0)
    times_used = models.PositiveIntegerField(default=0)

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.code

    def is_valid(self, order_total):
        now = timezone.now()
        if not self.is_active:
            return False, 'This coupon is no longer active.'
        if not (self.valid_from <= now <= self.valid_to):
            return False, 'This coupon has expired or is not yet active.'
        if self.usage_limit and self.times_used >= self.usage_limit:
            return False, 'This coupon has reached its usage limit.'
        if order_total < self.min_purchase_amount:
            return False, f'Minimum purchase for this coupon is ${self.min_purchase_amount}.'
        return True, ''

    def calculate_discount(self, order_total):
        if self.discount_type == self.DISCOUNT_PERCENTAGE:
            discount = (order_total * self.discount_value) / Decimal('100')
            if self.max_discount_amount is not None:
                discount = min(discount, self.max_discount_amount)
        else:
            discount = self.discount_value
        return min(discount, order_total)


class Order(models.Model):
    STATUS_PENDING = 'pending'
    STATUS_PAID = 'paid'
    STATUS_PROCESSING = 'processing'
    STATUS_SHIPPED = 'shipped'
    STATUS_OUT_FOR_DELIVERY = 'out_for_delivery'
    STATUS_DELIVERED = 'delivered'
    STATUS_CANCELLED = 'cancelled'

    STATUS_CHOICES = (
        (STATUS_PENDING, 'Pending'),
        (STATUS_PAID, 'Paid'),
        (STATUS_PROCESSING, 'Processing'),
        (STATUS_SHIPPED, 'Shipped'),
        (STATUS_OUT_FOR_DELIVERY, 'Out for Delivery'),
        (STATUS_DELIVERED, 'Delivered'),
        (STATUS_CANCELLED, 'Cancelled'),
    )

    STATUS_FLOW = [
        STATUS_PENDING,
        STATUS_PAID,
        STATUS_PROCESSING,
        STATUS_SHIPPED,
        STATUS_OUT_FOR_DELIVERY,
        STATUS_DELIVERED,
    ]

    # Delivery Methods
    DELIVERY_STANDARD = 'standard'
    DELIVERY_EXPRESS = 'express'
    DELIVERY_SAME_DAY = 'same_day'

    DELIVERY_METHOD_CHOICES = (
        (DELIVERY_STANDARD, 'Standard'),
        (DELIVERY_EXPRESS, 'Express'),
        (DELIVERY_SAME_DAY, 'Same Day'),
    )

    DELIVERY_CHARGES = {
        DELIVERY_STANDARD: 5,
        DELIVERY_EXPRESS: 10,
        DELIVERY_SAME_DAY: 15,
    }

    # Payment Status
    PAYMENT_PENDING = 'pending'
    PAYMENT_PAID = 'paid'
    PAYMENT_FAILED = 'failed'
    PAYMENT_REFUNDED = 'refunded'

    PAYMENT_STATUS_CHOICES = (
        (PAYMENT_PENDING, 'Pending'),
        (PAYMENT_PAID, 'Paid'),
        (PAYMENT_FAILED, 'Failed'),
        (PAYMENT_REFUNDED, 'Refunded'),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='orders',
    )

    shipping_address = models.ForeignKey(
        Address,
        on_delete=models.PROTECT,
        related_name='shipping_orders',
    )

    billing_address = models.ForeignKey(
        Address,
        on_delete=models.PROTECT,
        related_name='billing_orders',
        null=True,
        blank=True,
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
    )

    total_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    subtotal = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    product_discount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    coupon_discount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    delivery_charge = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    grand_total = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    delivery_method = models.CharField(
        max_length=20,
        choices=DELIVERY_METHOD_CHOICES,
        default=DELIVERY_STANDARD,
    )

    payment_method = models.CharField(
        max_length=50,
        blank=True,
    )

    payment_status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default=PAYMENT_PENDING,
    )

    stripe_payment_intent = models.CharField(
        max_length=255,
        blank=True,
    )

    notes = models.TextField(blank=True)

    tracking_number = models.CharField(
        max_length=100,
        blank=True,
        default='',
    )

    tracking_url = models.URLField(
        blank=True,
        help_text='Optional courier tracking page URL, if the courier provides one.',
    )

    estimated_delivery = models.DateField(
        null=True,
        blank=True,
        help_text='Optional estimated delivery date shown to the customer.',
    )

    shipped_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    delivered_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    coupon = models.ForeignKey(
        Coupon,
        on_delete=models.SET_NULL,
        related_name='orders',
        null=True,
        blank=True,
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Order #{self.pk} ({self.user.username})"

    @classmethod
    def get_delivery_charge(cls, delivery_method):
        return cls.DELIVERY_CHARGES.get(delivery_method, 0)

    @property
    def current_status_index(self):
        if self.status in self.STATUS_FLOW:
            return self.STATUS_FLOW.index(self.status)
        return -1

    @property
    def tracking_steps(self):
        return [
            ('Pending', self.STATUS_PENDING),
            ('Paid', self.STATUS_PAID),
            ('Processing', self.STATUS_PROCESSING),
            ('Shipped', self.STATUS_SHIPPED),
            ('Out For Delivery', self.STATUS_OUT_FOR_DELIVERY),
            ('Delivered', self.STATUS_DELIVERED),
        ]


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='items',
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
    )

    quantity = models.PositiveIntegerField(default=1)

    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
    )

    list_price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )

    variant_label = models.CharField(
        max_length=100,
        blank=True,
    )

    class Meta:
        ordering = ['id']

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

    @property
    def subtotal(self):
        return self.price * self.quantity

    @property
    def discount_per_unit(self):
        return max(self.list_price - self.price, 0)

    @property
    def discount_total(self):
        return self.discount_per_unit * self.quantity

    @property
    def total_before_discount(self):
        return self.list_price * self.quantity

    @property
    def has_discount(self):
        return self.discount_total > 0

    @property
    def variant_display(self):
        return self.variant_label