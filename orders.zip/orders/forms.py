from django import forms

from accounts.models import Address

from .models import Order


class CheckoutForm(forms.Form):
    """Phase 1: Smart Checkout — Shipping Address, Billing Address (with a
    'same as shipping' shortcut), Delivery Method, and an optional note."""

    shipping_address = forms.ModelChoiceField(
        queryset=Address.objects.none(), empty_label=None,
        label="Shipping Address",
    )
    billing_same_as_shipping = forms.BooleanField(
        required=False, initial=True, label="Same as shipping",
    )
    billing_address = forms.ModelChoiceField(
        queryset=Address.objects.none(), required=False,
        empty_label="Select a billing address", label="Billing Address",
    )
    delivery_method = forms.ChoiceField(
        choices=Order.DELIVERY_CHOICES, initial=Order.DELIVERY_STANDARD,
        widget=forms.RadioSelect, label="Delivery Method",
    )
    notes = forms.CharField(
        required=False, widget=forms.Textarea(attrs={"rows": 2}),
        label="Order notes (optional)",
    )

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user is not None:
            addresses = Address.objects.filter(user=user)
            self.fields["shipping_address"].queryset = addresses
            self.fields["billing_address"].queryset = addresses

    def clean(self):
        cleaned_data = super().clean()
        if not cleaned_data.get("billing_same_as_shipping") and not cleaned_data.get("billing_address"):
            self.add_error(
                "billing_address",
                'Select a billing address, or check "Same as shipping".',
            )
        return cleaned_data

    def get_billing_address(self):
        if self.cleaned_data.get("billing_same_as_shipping"):
            return self.cleaned_data["shipping_address"]
        return self.cleaned_data["billing_address"]


class CouponApplyForm(forms.Form):
    code = forms.CharField(
        max_length=30, label="Coupon code",
        widget=forms.TextInput(attrs={"placeholder": "e.g. SAVE20"}),
    )