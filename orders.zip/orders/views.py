from decimal import Decimal

import stripe

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import Address
from products.models import Product

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from . import services
from .models import Order, OrderItem


stripe.api_key = getattr(settings, 'STRIPE_SECRET_KEY', '')


# ============================================================
# 1. DJANGO TEMPLATE / BACKEND VIEWS
# ============================================================

@login_required
def checkout(request):
    # Only logged-in user's addresses
    addresses = request.user.addresses.all()

    if request.method == 'POST':
        address_id = request.POST.get('address_id')

        # IMPORTANT:
        # User can only select their own address
        address = get_object_or_404(
            Address,
            pk=address_id,
            user=request.user
        )

        try:
            order = services.create_order_from_cart(
                request.user,
                address
            )

            messages.success(
                request,
                f'Order #{order.pk} placed successfully!'
            )

            return redirect(
                'orders:detail',
                order_id=order.pk
            )

        except ValidationError as e:
            messages.error(
                request,
                e.message if hasattr(e, 'message') else str(e)
            )

    return render(
        request,
        'orders/checkout.html',
        {
            'addresses': addresses
        }
    )


@login_required
def order_list(request):
    orders = services.get_user_orders(request.user)

    return render(
        request,
        'orders/order_list.html',
        {
            'orders': orders
        }
    )


@login_required
def order_detail(request, order_id):
    order = get_object_or_404(
        services.get_user_orders(request.user),
        pk=order_id
    )

    return render(
        request,
        'orders/order_detail.html',
        {
            'order': order
        }
    )


@login_required
def cancel_order(request, order_id):
    if request.method == 'POST':
        try:
            services.cancel_order(
                request.user,
                order_id
            )

            messages.success(
                request,
                'Order cancelled.'
            )

        except ValidationError as e:
            messages.error(
                request,
                e.message if hasattr(e, 'message') else str(e)
            )

    return redirect(
        'orders:detail',
        order_id=order_id
    )


# ============================================================
# 2. REACT REST API
#    Supports COD + Stripe
# ============================================================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def api_create_order(request):

    user = request.user
    data = request.data

    # --------------------------------------------------------
    # Get order items
    # --------------------------------------------------------

    items_data = data.get('items', [])

    if not items_data:
        return Response(
            {
                'error': 'No items in the order.'
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    # --------------------------------------------------------
    # Get selected address ID
    # --------------------------------------------------------

    address_id = data.get('address_id')

    if not address_id:
        return Response(
            {
                'error': 'Please select a delivery address.'
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    # --------------------------------------------------------
    # VERY IMPORTANT:
    # Only allow the logged-in user's own address
    # --------------------------------------------------------

    try:
        shipping_address = Address.objects.get(
            id=address_id,
            user=user
        )

    except Address.DoesNotExist:
        return Response(
            {
                'error': 'Selected address does not belong to this user.'
            },
            status=status.HTTP_403_FORBIDDEN
        )

    # --------------------------------------------------------
    # Payment method
    # --------------------------------------------------------

    payment_method = str(
        data.get('payment_method', 'cod')
    ).lower()

    if payment_method not in ['cod', 'card']:
        return Response(
            {
                'error': 'Invalid payment method.'
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    # --------------------------------------------------------
    # Optional delivery method
    # --------------------------------------------------------

    delivery_method = data.get(
        'delivery_method',
        Order.DELIVERY_STANDARD
    )

    if delivery_method not in dict(
        Order.DELIVERY_METHOD_CHOICES
    ):
        delivery_method = Order.DELIVERY_STANDARD

    # --------------------------------------------------------
    # Create order
    # --------------------------------------------------------

    try:

        with transaction.atomic():

            subtotal = Decimal('0.00')

            stripe_line_items = []

            # ------------------------------------------------
            # Create Order first
            # ------------------------------------------------

            order = Order.objects.create(
                user=user,

                # IMPORTANT:
                # This is an Address object, NOT a string
                shipping_address=shipping_address,

                # Billing address can be same as shipping
                billing_address=shipping_address,

                status=Order.STATUS_PENDING,

                total_amount=Decimal('0.00'),

                subtotal=Decimal('0.00'),

                product_discount=Decimal('0.00'),

                coupon_discount=Decimal('0.00'),

                delivery_charge=Decimal('0.00'),

                grand_total=Decimal('0.00'),

                delivery_method=delivery_method,

                payment_method=payment_method,

                payment_status=Order.PAYMENT_PENDING,
            )

            # ------------------------------------------------
            # Process each product
            # ------------------------------------------------

            for item in items_data:

                product_id = (
                    item.get('product_id')
                    or item.get('id')
                )

                quantity = int(
                    item.get('quantity', 1)
                )

                if not product_id:
                    raise ValueError(
                        'Product ID is missing.'
                    )

                if quantity <= 0:
                    raise ValueError(
                        'Quantity must be at least 1.'
                    )

                # --------------------------------------------
                # Lock product row
                # --------------------------------------------

                product = Product.objects.select_for_update().get(
                    id=product_id
                )

                # --------------------------------------------
                # Check stock
                # --------------------------------------------

                if product.stock < quantity:
                    raise ValueError(
                        f'Not enough stock for {product.name}.'
                    )

                # --------------------------------------------
                # ALWAYS use database product price
                # Don't trust frontend price
                # --------------------------------------------

                item_price = Decimal(
                    str(product.price)
                )

                item_subtotal = (
                    item_price * quantity
                )

                subtotal += item_subtotal

                # --------------------------------------------
                # Reduce stock
                # --------------------------------------------

                product.stock -= quantity

                product.save(
                    update_fields=['stock']
                )

                # --------------------------------------------
                # Create OrderItem
                # --------------------------------------------

                OrderItem.objects.create(
                    order=order,
                    product=product,
                    price=item_price,
                    list_price=item_price,
                    quantity=quantity,
                )

                # --------------------------------------------
                # Stripe line item
                # --------------------------------------------

                if payment_method == 'card':

                    stripe_line_items.append(
                        {
                            'price_data': {
                                'currency': 'usd',

                                'product_data': {
                                    'name': product.name,
                                },

                                'unit_amount': int(
                                    item_price * 100
                                ),
                            },

                            'quantity': quantity,
                        }
                    )

            # ------------------------------------------------
            # Delivery charge
            # ------------------------------------------------

            # Keep delivery charge 0 for now so your current
            # checkout total remains $1234 instead of changing.
            delivery_charge = Decimal('0.00')

            # ------------------------------------------------
            # Final total
            # ------------------------------------------------

            grand_total = (
                subtotal
                + delivery_charge
            )

            order.subtotal = subtotal
            order.delivery_charge = delivery_charge
            order.total_amount = grand_total
            order.grand_total = grand_total

            order.save()

            # =================================================
            # STRIPE PAYMENT
            # =================================================

            if payment_method == 'card':

                if not settings.STRIPE_SECRET_KEY:
                    raise ValueError(
                        'Stripe secret key is not configured.'
                    )

                stripe.api_key = settings.STRIPE_SECRET_KEY

                checkout_session = (
                    stripe.checkout.Session.create(

                        payment_method_types=[
                            'card'
                        ],

                        line_items=stripe_line_items,

                        mode='payment',

                        success_url=(
                            'http://localhost:5173/'
                            'payment-success'
                            f'?order_id={order.id}'
                        ),

                        cancel_url=(
                            'http://localhost:5173/checkout'
                        ),

                        client_reference_id=str(
                            order.id
                        ),

                        customer_email=user.email,
                    )
                )

                order.stripe_payment_intent = (
                    checkout_session.id
                )

                order.save(
                    update_fields=[
                        'stripe_payment_intent'
                    ]
                )

                return Response(
                    {
                        'message': (
                            'Order created. '
                            'Redirecting to payment...'
                        ),

                        'order_id': order.id,

                        'total_amount': str(
                            order.grand_total
                        ),

                        'payment_method': 'card',

                        'stripe_url': (
                            checkout_session.url
                        ),
                    },

                    status=status.HTTP_201_CREATED
                )

            # =================================================
            # CASH ON DELIVERY
            # =================================================

            return Response(
                {
                    'message': (
                        'Order placed successfully '
                        'with Cash on Delivery.'
                    ),

                    'order_id': order.id,

                    'total_amount': str(
                        order.grand_total
                    ),

                    'payment_method': 'cod',

                    'payment_status': (
                        order.payment_status
                    ),
                },

                status=status.HTTP_201_CREATED
            )

    # ========================================================
    # ERROR HANDLING
    # ========================================================

    except Product.DoesNotExist:

        return Response(
            {
                'error': (
                    'One or more products '
                    'were not found.'
                )
            },
            status=status.HTTP_404_NOT_FOUND
        )

    except ValueError as e:

        return Response(
            {
                'error': str(e)
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    except stripe.error.StripeError as e:

        return Response(
            {
                'error': (
                    f'Stripe payment error: {str(e)}'
                )
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    except Exception as e:

        return Response(
            {
                'error': str(e)
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )