# orders/services.py

from decimal import Decimal
from django.core.exceptions import ValidationError
from django.db import transaction

from cart.models import Cart
from products.services import is_purchasable
from .models import Order, OrderItem


def get_user_orders(user):
    return Order.objects.filter(user=user).order_by('-created_at')


def get_order(user, order_id):
    return Order.objects.filter(user=user, pk=order_id).prefetch_related('items').first()


@transaction.atomic
def create_order_from_cart(user, shipping_address):
    cart = Cart.objects.filter(user=user).first()
    if not cart or not cart.items.exists():
        raise ValidationError("Your cart is empty.")

    # 1. স্টক চেক করা
    for item in cart.items.all():
        if not is_purchasable(item.product, item.quantity):
            raise ValidationError(f'"{item.product.name}" does not have enough stock.')

    # 2. Order তৈরি করা
    order = Order.objects.create(
        user=user,
        shipping_address=shipping_address,
        status=Order.STATUS_PENDING,
        payment_status=Order.PAYMENT_PENDING,
        delivery_method=Order.DELIVERY_STANDARD,
    )

    subtotal = Decimal('0.00')

    # 3. OrderItems তৈরি করা ও স্টক কমানো
    for item in cart.items.all():
        item_price = item.product.price
        OrderItem.objects.create(
            order=order,
            product=item.product,
            quantity=item.quantity,
            price=item_price,
            list_price=item_price,
            variant_label=""
        )

        # স্টক আপডেট
        item.product.stock -= item.quantity
        item.product.save(update_fields=['stock'])

        subtotal += (item_price * item.quantity)

    # 4. ডেলিভারি চার্জ ও মোট হিসেব করা
    delivery_charge = Decimal(str(Order.get_delivery_charge(order.delivery_method)))
    order.subtotal = subtotal
    order.delivery_charge = delivery_charge
    order.grand_total = subtotal + delivery_charge
    order.total_amount = order.grand_total
    order.save()

    # 5. কার্ট খালি করা
    cart.items.all().delete()
    return order


def mark_order_paid(order, payment_method='Stripe (Credit Card)'):
    """Marks the order as paid when payment succeeds."""
    if isinstance(order, (int, str)):
        order = Order.objects.get(pk=order)

    order.payment_status = Order.PAYMENT_PAID
    order.status = Order.STATUS_PAID
    order.payment_method = payment_method
    order.save()
    return order


def cancel_order(user, order_id):
    order = get_order(user, order_id)
    if not order:
        raise ValidationError("Order not found.")
    if order.status != Order.STATUS_PENDING:
        raise ValidationError("Only pending orders can be cancelled.")
    order.status = Order.STATUS_CANCELLED
    order.save(update_fields=['status'])
    return order