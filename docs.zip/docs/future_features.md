# Planned features (not yet implemented)

These are scoped but intentionally left out of the current build so the
core storefront (accounts → category → products → cart → orders →
payments) ships first. Each one is designed to slot into the existing
app structure without a rewrite.

## Wishlist
- New `wishlist` app, or a `Wishlist`/`WishlistItem` pair of models similar
  in shape to `cart.Cart` / `cart.CartItem` (a `OneToOneField` to `User`,
  a FK to `Product`).
- `wishlist/services.py`: `add_to_wishlist`, `remove_from_wishlist`,
  `move_to_cart` (reuses `cart.services.add_to_cart`).
- UI: a heart/save icon on `products/product_detail.html` and
  `products/product_list.html`.

## Product Reviews
- Lives in the `products` app — see the commented-out `Review` model at the
  bottom of `products/models.py` (`product` FK, `user` FK, `rating`
  1–5, `comment`, `created_at`).
- Business rule to enforce in `products/services.py`: only users who have
  an `OrderItem` for that product may review it (verified purchase).
- Add an average-rating annotation to `products.services.get_active_products`
  once reviews exist (`.annotate(avg_rating=Avg('reviews__rating'))`).

## Coupons / Discounts
- New `coupons` app with a `Coupon` model (`code`, `discount_type`
  `percentage`/`fixed`, `amount`, `valid_from`, `valid_to`, `is_active`,
  `max_uses`).
- `coupons/services.py`: `validate_coupon(code, cart)` → raises
  `ValidationError` or returns the discount amount.
- Wire into `orders.services.create_order_from_cart(user, address, coupon_code=None)`
  so the discount is applied atomically alongside order creation.

## Notifications
- New `notifications` app with a `Notification` model (`user` FK,
  `message`, `is_read`, `created_at`) plus `notifications/services.py`
  (`notify_user`, `mark_as_read`).
- Hook points that already exist and just need a `notify_user(...)` call
  added once this app exists: `orders.services.create_order_from_cart`
  (order placed), `payments.services.process_payment` (payment
  success/failure), `orders.services.cancel_order` (order cancelled).
- Start with in-app notifications (a bell icon + unread count in
  `templates/base.html`); email/SMS delivery can be layered on later via
  the same `send_mail`/`EMAIL_*` settings already configured from `.env`.
