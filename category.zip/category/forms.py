from django import forms

from .models import Category, SubCategory


class CategoryForm(forms.ModelForm):
    """Used for both Add Category and Edit Category — the slug is derived
    from the name automatically in Category.save(), so it isn't shown here."""

    class Meta:
        model = Category
        fields = ['name', 'description', 'image', 'is_active']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }


class SubCategoryForm(forms.ModelForm):
    """Used for both Add SubCategory and Edit SubCategory."""

    class Meta:
        model = SubCategory
        fields = ['category', 'name', 'description', 'image', 'is_active']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
