from django.shortcuts import get_object_or_404, render

from . import services
from .models import Category


def category_list(request):
    categories = services.get_active_categories()
    return render(
        request,
        'category/category_list.html',
        {
            'categories': categories,
        },
    )


def category_detail(request, slug):
    category = get_object_or_404(
        Category,
        slug=slug,
        is_active=True,
    )

    products = (
        category.products
        .filter(is_active=True)
        .order_by('-created_at')
    )

    return render(
        request,
        'category/category_detail.html',
        {
            'category': category,
            'products': products,
        },
    )