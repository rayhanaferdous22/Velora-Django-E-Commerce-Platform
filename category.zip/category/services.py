from .models import Category


def get_active_categories():
    """Return top-level active categories for the customer storefront."""
    return Category.objects.filter(is_active=True, parent__isnull=True)


def get_category_by_slug(slug):
    """Return a single active category by its slug."""
    return Category.objects.filter(slug=slug, is_active=True).first()


def get_category_tree():
    """Return active top-level categories with prefetched child categories."""
    return (
        Category.objects.filter(is_active=True, parent__isnull=True)
        .prefetch_related('children')
    )