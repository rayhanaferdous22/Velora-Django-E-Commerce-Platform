"""Staff-only category/subcategory management, mounted at /admin/categories/
(kept separate from Django's own /admin/ site, and included BEFORE it in
velora_project/urls.py so this prefix is matched first)."""

from django.urls import path

from . import views

app_name = 'category'

urlpatterns = [
    path('', views.category_manage_list, name='list'),
    path('add/', views.category_create, name='add'),
    path('<slug:slug>/edit/', views.category_update, name='edit'),
    path('<slug:slug>/delete/', views.category_delete, name='delete'),

    path('subcategories/add/', views.subcategory_create, name='subcategory_add'),
    path('subcategories/<slug:slug>/edit/', views.subcategory_update, name='subcategory_edit'),
    path('subcategories/<slug:slug>/delete/', views.subcategory_delete, name='subcategory_delete'),
]
