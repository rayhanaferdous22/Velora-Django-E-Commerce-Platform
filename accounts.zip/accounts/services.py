"""Business logic for accounts (registration, auth, profile, addresses),
kept out of views.py so views stay thin and this logic is directly testable."""

from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

from .models import Address, UserProfile
from .utils import email_verification_token


# ---------------------------------------------------------------------------
# Registration / email verification
# ---------------------------------------------------------------------------
def register_user(*, first_name, last_name, username, email, password, phone=''):
    if User.objects.filter(email__iexact=email).exists():
        raise ValidationError('An account with this email already exists.')

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
    )
    # UserProfile is auto-created by the post_save signal; just fill in the phone.
    profile, _ = UserProfile.objects.get_or_create(user=user)
    profile.phone = phone
    profile.save(update_fields=['phone'])
    return user


def send_verification_email(request, user):
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = email_verification_token.make_token(user)
    verify_path = reverse('accounts:verify_email', kwargs={'uidb64': uid, 'token': token})
    verify_url = request.build_absolute_uri(verify_path)

    message = render_to_string(
        'accounts/emails/verify_email.txt', {'user': user, 'verify_url': verify_url}
    )
    send_mail('Verify your email address', message, None, [user.email], fail_silently=True)


def verify_email(uid, token):
    from django.utils.encoding import force_str
    from django.utils.http import urlsafe_base64_decode

    try:
        pk = force_str(urlsafe_base64_decode(uid))
        user = User.objects.get(pk=pk)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None

    if not email_verification_token.check_token(user, token):
        return None

    profile, _ = UserProfile.objects.get_or_create(user=user)
    profile.email_verified = True
    profile.save(update_fields=['email_verified'])
    return user


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------
def authenticate_by_identifier(request, identifier, password):
    """Allow logging in with either a username or an email address."""
    username = identifier
    if '@' in identifier:
        matched = User.objects.filter(email__iexact=identifier).first()
        if matched:
            username = matched.username
    return authenticate(request, username=username, password=password)


# ---------------------------------------------------------------------------
# Password reset
# ---------------------------------------------------------------------------
def send_password_reset_email(request, email):
    """Always returns normally, whether or not the email exists, so callers
    can show the same message either way (avoids leaking registered emails)."""
    user = User.objects.filter(email__iexact=email).first()
    if not user:
        return

    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    reset_path = reverse('accounts:reset_password_confirm', kwargs={'uidb64': uid, 'token': token})
    reset_url = request.build_absolute_uri(reset_path)

    message = render_to_string(
        'accounts/emails/reset_password.txt', {'user': user, 'reset_url': reset_url}
    )
    send_mail('Reset your password', message, None, [user.email], fail_silently=True)


def get_user_from_reset_token(uidb64, token):
    from django.utils.encoding import force_str
    from django.utils.http import urlsafe_base64_decode

    try:
        pk = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=pk)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None

    if not default_token_generator.check_token(user, token):
        return None
    return user


def reset_password(user, new_password):
    from django.contrib.auth.password_validation import validate_password

    validate_password(new_password, user=user)
    user.set_password(new_password)
    user.save(update_fields=['password'])


# ---------------------------------------------------------------------------
# Address book
# ---------------------------------------------------------------------------
def get_user_addresses(user):
    return user.addresses.all()


def create_address(user, **fields):
    return Address.objects.create(user=user, **fields)
