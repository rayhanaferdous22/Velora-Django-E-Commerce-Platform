from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect


def guest_only(view_func):
    """Redirect already-authenticated users away from guest-only pages
    like login/register (mirrors the roadmap's Guest vs Customer split)."""

    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('accounts:dashboard')
        return view_func(request, *args, **kwargs)

    return wrapper


def admin_required(view_func):
    """Restrict a view to staff/admin users only."""

    @wraps(view_func)
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_staff:
            messages.error(request, "You don't have permission to access that page.")
            return redirect('accounts:dashboard')
        return view_func(request, *args, **kwargs)

    return wrapper
