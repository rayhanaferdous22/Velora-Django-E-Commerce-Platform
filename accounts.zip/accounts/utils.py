from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode


class EmailVerificationTokenGenerator(PasswordResetTokenGenerator):
    """Separate token generator so verification links can't be reused as
    password-reset links, and vice versa."""

    def _make_hash_value(self, user, timestamp):
        return f"{user.pk}{timestamp}{user.is_active}{user.profile.email_verified}"


email_verification_token = EmailVerificationTokenGenerator()


def send_verification_email(request, user):
    """Send an email-verification link to a newly registered user."""
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = email_verification_token.make_token(user)
    verify_path = f"/accounts/verify-email/{uid}/{token}/"
    verify_url = request.build_absolute_uri(verify_path)

    subject = 'Verify your email address'
    message = render_to_string(
        'accounts/emails/verify_email.txt',
        {'user': user, 'verify_url': verify_url},
    )
    send_mail(subject, message, None, [user.email], fail_silently=False)


def send_password_reset_email(request, user, uid, token):
    reset_path = f"/accounts/reset-password/{uid}/{token}/"
    reset_url = request.build_absolute_uri(reset_path)

    subject = 'Reset your password'
    message = render_to_string(
        'accounts/emails/reset_password.txt',
        {'user': user, 'reset_url': reset_url},
    )
    send_mail(subject, message, None, [user.email], fail_silently=False)
