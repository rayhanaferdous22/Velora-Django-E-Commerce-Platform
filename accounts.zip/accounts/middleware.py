from django.shortcuts import redirect
from django.urls import reverse


class ActiveUserRequiredMiddleware:
    """Logs out any user whose account has been deactivated mid-session,
    matching the roadmap's login-flow 'Is Active?' check being enforced
    continuously rather than only at login time."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and not request.user.is_active:
            from django.contrib.auth import logout

            logout(request)
            return redirect(reverse('accounts:login'))
        return self.get_response(request)
