from django.contrib import admin

from .models import Address, UserProfile

admin.site.site_header = 'VELORA Administration'
admin.site.site_title = 'VELORA Admin'
admin.site.index_title = 'Manage VELORA'


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone', 'gender', 'email_verified', 'created_at')
    list_filter = ('gender', 'email_verified')
    search_fields = ('user__username', 'user__email', 'phone')


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('user', 'division', 'district', 'thana', 'is_default')
    list_filter = ('division', 'is_default')
    search_fields = ('user__username', 'district', 'thana')
