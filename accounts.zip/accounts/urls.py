from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [

    # ---------------------------------------------------------------------------
    # REST API Routes (React Frontend)
    # ---------------------------------------------------------------------------
    path('register/', views.api_register, name='api_register'),
    path('login/', views.api_login, name='api_login'),
    path('profile/', views.api_user_profile, name='api_profile'),
    path('addresses/', views.api_addresses, name='api_addresses'),

    # ---------------------------------------------------------------------------
    # Django Template Web Views (Traditional Web)
    # ---------------------------------------------------------------------------
    path('web/register/', views.user_register, name='web_register'),
    path('web/login/', views.user_login, name='web_login'),
    path('web/login/', views.user_login, name='login'),
    path('web/logout/', views.user_logout, name='web_logout'),
    path('web/dashboard/', views.dashboard, name='dashboard'),
]