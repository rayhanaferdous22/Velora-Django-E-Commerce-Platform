from django.contrib.auth import get_user_model
from rest_framework import serializers
from .models import Address, UserProfile

User = get_user_model()


class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['profile_image', 'phone', 'gender', 'birth_date', 'email_verified']


class UserSerializer(serializers.ModelSerializer):
    profile = UserProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'is_staff', 'profile']


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['id', 'division', 'district', 'thana', 'road', 'house', 'zip_code', 'is_default']
        read_only_fields = ['id', 'user']
        extra_kwargs = {
            'division': {'required': False, 'allow_blank': True},
            'district': {'required': False, 'allow_blank': True},
            'thana': {'required': False, 'allow_blank': True},
            'road': {'required': False, 'allow_blank': True},
            'house': {'required': False, 'allow_blank': True},
            'zip_code': {'required': False, 'allow_blank': True},
            'is_default': {'required': False},
        }