from django.core.exceptions import ValidationError
from django.db import transaction

from orders.services import mark_order_paid

from .models import Payment


@transaction.atomic
def process_payment(order, method):
    """
    Process a normal payment record.

    Stripe card payments are handled by payments.views
    through Stripe Checkout.

    This function is mainly used for non-Stripe/manual
    payment methods such as Cash on Delivery.
    """

    if hasattr(order, "payment"):
        raise ValidationError(
            "This order has already been paid for."
        )

    payment = Payment.objects.create(
        order=order,
        method=method,
        amount=order.total_amount,
        status=Payment.STATUS_PENDING,
    )

    # Cash on Delivery is not actually paid yet.
    if method.lower() in [
        "cod",
        "cash",
        "cash on delivery",
    ]:
        return payment

    return payment


@transaction.atomic
def mark_payment_success(payment):
    """
    Mark an existing payment as successful.
    """

    payment.status = Payment.STATUS_SUCCESS

    payment.save(
        update_fields=["status"]
    )

    mark_order_paid(
        payment.order,
        payment_method=payment.method
    )

    return payment


@transaction.atomic
def refund_payment(payment):
    """
    Mark a payment as refunded.

    Actual Stripe refund API can be added later
    if refund functionality is required.
    """

    payment.status = Payment.STATUS_REFUNDED

    payment.save(
        update_fields=["status"]
    )

    return payment