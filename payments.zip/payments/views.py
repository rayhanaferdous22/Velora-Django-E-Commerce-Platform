import stripe

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse

from orders.models import Order
from orders.services import mark_order_paid


stripe.api_key = getattr(settings, "STRIPE_SECRET_KEY", "")


@login_required
def create_checkout_session(request, order_id):
    """
    Create a Stripe Checkout Session for an existing order.
    """

    order = get_object_or_404(
        Order,
        pk=order_id,
        user=request.user,
    )

    # Make sure Stripe secret key exists.
    if not settings.STRIPE_SECRET_KEY:
        messages.error(
            request,
            "Stripe secret key is not configured."
        )
        return redirect(
            "orders:detail",
            order_id=order.pk
        )

    # Get order total.
    total = (
        order.grand_total
        if hasattr(order, "grand_total")
        else order.total_amount
    )

    try:
        total = float(total)
    except (TypeError, ValueError):
        messages.error(
            request,
            "Invalid order total."
        )
        return redirect(
            "orders:detail",
            order_id=order.pk
        )

    if total <= 0:
        messages.error(
            request,
            "Order amount must be greater than zero."
        )
        return redirect(
            "orders:detail",
            order_id=order.pk
        )

    amount_in_cents = int(round(total * 100))

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],

            line_items=[
                {
                    "price_data": {
                        "currency": "usd",

                        "product_data": {
                            "name": f"Velora Order #{order.pk}",
                        },

                        "unit_amount": amount_in_cents,
                    },

                    "quantity": 1,
                }
            ],

            mode="payment",

            # Stripe will return here after successful payment.
            success_url=(
                request.build_absolute_uri(
                    "/payments/success/"
                )
                + f"?session_id={{CHECKOUT_SESSION_ID}}"
            ),

            # Stripe will return here if customer cancels.
            cancel_url=request.build_absolute_uri(
                f"/payments/{order.pk}/cancel/"
            ),

            # Store order ID inside Stripe session metadata.
            metadata={
                "order_id": str(order.pk),
            },
        )

        return redirect(
            session.url,
            code=303
        )

    except stripe.error.StripeError as e:
        error_message = getattr(
            e,
            "user_message",
            None
        ) or str(e)

        messages.error(
            request,
            f"Stripe Error: {error_message}"
        )

        return redirect(
            "orders:detail",
            order_id=order.pk
        )

    except Exception as e:
        messages.error(
            request,
            f"Payment failed: {str(e)}"
        )

        return redirect(
            "orders:detail",
            order_id=order.pk
        )


# Keep the old name working.
initiate_payment = create_checkout_session


@login_required
def payment_success(request):
    """
    Verify the Stripe Checkout Session before marking
    the order as paid.
    """

    session_id = request.GET.get("session_id")

    if not session_id:
        messages.error(
            request,
            "Payment session was not found."
        )
        return redirect("/")

    if not settings.STRIPE_SECRET_KEY:
        messages.error(
            request,
            "Stripe secret key is not configured."
        )
        return redirect("/")

    try:
        session = stripe.checkout.Session.retrieve(
            session_id
        )

        # Make sure this payment belongs to the logged-in user.
        order_id = session.metadata.get("order_id")

        if not order_id:
            messages.error(
                request,
                "Order information was not found."
            )
            return redirect("/")

        order = get_object_or_404(
            Order,
            pk=order_id,
            user=request.user,
        )

        # Only mark paid when Stripe confirms payment.
        if session.payment_status == "paid":

            order = mark_order_paid(
                order.pk,
                payment_method="Stripe (Credit Card)"
            )

        else:
            messages.warning(
                request,
                "Payment has not been confirmed by Stripe yet."
            )

        return render(
            request,
            "payments/success.html",
            {
                "order": order,
                "stripe_session": session,
            }
        )

    except stripe.error.StripeError as e:
        error_message = getattr(
            e,
            "user_message",
            None
        ) or str(e)

        messages.error(
            request,
            f"Stripe Error: {error_message}"
        )

        return redirect("/")

    except Exception as e:
        messages.error(
            request,
            f"Payment verification failed: {str(e)}"
        )

        return redirect("/")


@login_required
def payment_cancel(request, order_id):
    messages.warning(
        request,
        "Payment was cancelled."
    )

    return redirect(
        "orders:detail",
        order_id=order_id
    )


def stripe_webhook(request):
    """
    Basic Stripe webhook endpoint.

    This endpoint verifies the Stripe webhook signature
    when STRIPE_WEBHOOK_SECRET is configured.
    """

    payload = request.body
    sig_header = request.META.get(
        "HTTP_STRIPE_SIGNATURE"
    )

    webhook_secret = getattr(
        settings,
        "STRIPE_WEBHOOK_SECRET",
        ""
    )

    if not webhook_secret:
        return HttpResponse(
            "Webhook secret not configured.",
            status=200
        )

    try:
        event = stripe.Webhook.construct_event(
            payload,
            sig_header,
            webhook_secret,
        )

    except ValueError:
        return HttpResponse(
            "Invalid payload",
            status=400
        )

    except stripe.error.SignatureVerificationError:
        return HttpResponse(
            "Invalid signature",
            status=400
        )

    # Handle successful checkout.
    if event["type"] == "checkout.session.completed":

        session = event["data"]["object"]

        order_id = session.get(
            "metadata",
            {}
        ).get("order_id")

        if order_id:
            try:
                order = Order.objects.get(
                    pk=order_id
                )

                mark_order_paid(
                    order.pk,
                    payment_method="Stripe (Credit Card)"
                )

            except Order.DoesNotExist:
                pass

    return HttpResponse(
        "Webhook received",
        status=200
    )