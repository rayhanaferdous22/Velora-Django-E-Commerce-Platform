from django.urls import path

from . import views


app_name = "payments"


urlpatterns = [

    path(
        "<int:order_id>/pay/",
        views.initiate_payment,
        name="initiate",
    ),

    path(
        "<int:order_id>/checkout-session/",
        views.create_checkout_session,
        name="create_checkout_session",
    ),

    path(
        "success/",
        views.payment_success,
        name="success",
    ),

    path(
        "<int:order_id>/cancel/",
        views.payment_cancel,
        name="cancel",
    ),

    path(
        "webhook/",
        views.stripe_webhook,
        name="webhook",
    ),
]