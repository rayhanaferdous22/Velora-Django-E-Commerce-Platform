# cart/forms.py

from django import forms

from products.models import ProductVariant


class CartAddForm(forms.Form):
    """Used to add an item to the cart. product_id is now part of the form
    itself (rather than a URL kwarg), since /cart/add/ takes everything
    from the POST body."""

    product_id = forms.IntegerField(widget=forms.HiddenInput())
    quantity = forms.IntegerField(min_value=1, initial=1)
    variant_id = forms.IntegerField(required=False, widget=forms.HiddenInput())

    def clean_product_id(self):
        from products.models import Product

        try:
            product = Product.objects.get(pk=self.cleaned_data['product_id'], is_active=True)
        except Product.DoesNotExist:
            raise forms.ValidationError('This product is no longer available.')
        return product  # returns the object, not the raw id

    def clean_variant_id(self):
        variant_id = self.cleaned_data.get('variant_id')
        if not variant_id:
            return None
        try:
            return ProductVariant.objects.get(pk=variant_id, is_active=True)
        except ProductVariant.DoesNotExist:
            raise forms.ValidationError('That option is no longer available.')

    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get('product_id')
        variant = cleaned_data.get('variant_id')
        if product and variant and variant.product_id != product.id:
            self.add_error('variant_id', 'That variant does not belong to this product.')
        if product and product.has_variants and not variant:
            raise forms.ValidationError('Please select a color/size before adding this to your cart.')
        return cleaned_data

    @property
    def product(self):
        return self.cleaned_data.get('product_id')

    @property
    def variant(self):
        return self.cleaned_data.get('variant_id')


class CartUpdateForm(forms.Form):
    """Used by /cart/update/ — sets quantity directly, OR bumps it via an
    'action' of 'increase'/'decrease' if quantity isn't given."""

    product_id = forms.IntegerField(widget=forms.HiddenInput())
    variant_id = forms.IntegerField(required=False, widget=forms.HiddenInput())
    quantity = forms.IntegerField(min_value=0, required=False)
    action = forms.ChoiceField(
        choices=[('set', 'Set'), ('increase', 'Increase'), ('decrease', 'Decrease')],
        required=False,
        initial='set',
    )

    def clean(self):
        cleaned_data = super().clean()
        if not cleaned_data.get('action') and cleaned_data.get('quantity') is None:
            raise forms.ValidationError('Provide either a quantity or an increase/decrease action.')
        return cleaned_data